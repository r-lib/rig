
use builtin;
use str;

set edit:completion:arg-completer[rig] = {|@words|
    fn spaces {|n|
        builtin:repeat $n ' ' | str:join ''
    }
    fn cand {|text desc|
        edit:complex-candidate $text &display=$text' '(spaces (- 14 (wcswidth $text)))$desc
    }
    var command = 'rig'
    for word $words[1..-1] {
        if (str:has-prefix $word '-') {
            break
        }
        set command = $command';'$word
    }
    var completions = [
        &'rig'= {
            cand -q 'Suppress output (overrides `--verbose`)'
            cand --quiet 'Suppress output (overrides `--verbose`)'
            cand -v 'Verbose output'
            cand --verbose 'Verbose output'
            cand --json 'Output JSON'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help'
            cand --help 'Print help'
            cand -V 'Print version'
            cand --version 'Print version'
            cand config 'Manage rig configuration'
            cand proj 'Manage R projects (experimental)'
            cand pkg 'Manage R packages (experimental)'
            cand ppm 'Query Posit Package Manager (experimental)'
            cand repos 'Manage package repositories'
            cand default 'Print or set default R version [alias: switch]'
            cand list 'List installed R versions [alias: ls]'
            cand add 'Install a new R version [alias: install]'
            cand rm 'Remove R versions [aliases: del, remove, delete]'
            cand self 'Manage the rig installation itself'
            cand system 'Manage current installations'
            cand rtools 'Manage Rtools installations'
            cand resolve 'Resolve a symbolic R version'
            cand rstudio 'Start RStudio with specified R version'
            cand library 'Manage package libraries [alias: lib]'
            cand cache 'Manage rig''s download cache'
            cand available 'List R versions available to install.'
            cand run 'Run R, an R script or an R project'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'rig;config'= {
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
            cand config-file-path 'Print the path to the rig config file'
            cand list 'List the names of all config entries'
            cand get 'Get a config entry'
            cand set 'Set a config entry'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'rig;config;config-file-path'= {
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;config;list'= {
            cand --json 'JSON output'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;config;get'= {
            cand --json 'JSON output'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;config;set'= {
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;config;help'= {
            cand config-file-path 'Print the path to the rig config file'
            cand list 'List the names of all config entries'
            cand get 'Get a config entry'
            cand set 'Set a config entry'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'rig;config;help;config-file-path'= {
        }
        &'rig;config;help;list'= {
        }
        &'rig;config;help;get'= {
        }
        &'rig;config;help;set'= {
        }
        &'rig;config;help;help'= {
        }
        &'rig;proj'= {
            cand --json 'JSON output'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
            cand init 'Create a new R project'
            cand import 'Create rproj.toml from a DESCRIPTION file'
            cand export 'Create a DESCRIPTION file from rproj.toml'
            cand add 'Add dependencies to rproj.toml'
            cand remove 'Remove dependencies from rproj.toml'
            cand deps 'Show project dependencies'
            cand tree 'Dependency tree of a project'
            cand lock 'Resolve project dependencies and write rproj.lock'
            cand status 'Show the project''s status'
            cand sync 'Install the dependencies rproj.lock resolved'
            cand renv 'Interoperate with renv, R''s package management tool'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'rig;proj;init'= {
            cand -r 'R version of the project (default: the default R version, or the current R release)'
            cand --r-version 'R version of the project (default: the default R version, or the current R release)'
            cand --script 'Create the inline metadata block of this R script, instead of a project'
            cand --prefer-binary 'Write `prefer-binary` into the [tool.rig] table of the manifest, see `rig proj lock --prefer-binary`. Optionally give how many of the newest versions to consider, e.g. --prefer-binary=5 (default: 3). --prefer-binary=0 writes `prefer-binary = false`.'
            cand -f 'Overwrite existing project files'
            cand --force 'Overwrite existing project files'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;proj;import'= {
            cand -i 'DESCRIPTION file to import (e.g. DESCRIPTION)'
            cand --input 'DESCRIPTION file to import (e.g. DESCRIPTION)'
            cand -r 'R version of the project (default: the version the DESCRIPTION file requires, the default R version, or the current R release)'
            cand --r-version 'R version of the project (default: the version the DESCRIPTION file requires, the default R version, or the current R release)'
            cand --prefer-binary 'Write `prefer-binary` into the [tool.rig] table of the manifest, see `rig proj lock --prefer-binary`. Optionally give how many of the newest versions to consider, e.g. --prefer-binary=5 (default: 3). --prefer-binary=0 writes `prefer-binary = false`.'
            cand --dependencies 'Only merge dependencies, not metadata (the old behavior)'
            cand -f 'Overwrite existing project files'
            cand --force 'Overwrite existing project files'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;proj;export'= {
            cand -o 'Output file to write (e.g. DESCRIPTION)'
            cand --output 'Output file to write (e.g. DESCRIPTION)'
            cand -f 'Overwrite the output file if it already exists'
            cand --force 'Overwrite the output file if it already exists'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;proj;add'= {
            cand --script 'Add the packages to the inline metadata of this R script, instead of rproj.toml'
            cand --with-repos 'Add the packages from this repository: a repository name, URL or name=URL pair. A new repository is added to rproj.toml, and the packages are pinned to the first one. Comma-separated, and can be repeated.'
            cand --index 'Add the packages from this repository: a repository name, URL or name=URL pair. A new repository is added to rproj.toml, and the packages are pinned to the first one. Comma-separated, and can be repeated.'
            cand --dev 'Add as a dev (development) dependency'
            cand --no-lock 'Only update rproj.toml, do not update rproj.lock'
            cand --no-sync 'Do not install the added packages'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;proj;remove'= {
            cand --script 'Remove the packages from the inline metadata of this R script, instead of rproj.toml'
            cand --no-lock 'Only update rproj.toml, do not update rproj.lock'
            cand --no-sync 'Do not re-sync the project library'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;proj;deps'= {
            cand --with-repos 'Also use these repositories, a comma-separated list of repository names, URLs or name=URL pairs. Can be repeated.'
            cand --index 'Also use these repositories, a comma-separated list of repository names, URLs or name=URL pairs. Can be repeated.'
            cand --without-repos 'Do not use these repositories, a comma-separated list, e.g. cran,bioc. Without a value, do not use any of the project''s repositories, only the ones in --with-repos. Can be repeated.'
            cand --no-index 'Do not use these repositories, a comma-separated list, e.g. cran,bioc. Without a value, do not use any of the project''s repositories, only the ones in --with-repos. Can be repeated.'
            cand -r 'Show recursive (transitive) dependencies'
            cand --recursive 'Show recursive (transitive) dependencies'
            cand --json 'JSON output'
            cand --dev 'Include dev (development) dependencies'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;proj;tree'= {
            cand --why 'Invert the tree: show what pulls this package in'
            cand --explain 'Invert the tree: show what pulls this package in'
            cand --with-repos 'Also use these repositories, a comma-separated list of repository names, URLs or name=URL pairs. Can be repeated.'
            cand --index 'Also use these repositories, a comma-separated list of repository names, URLs or name=URL pairs. Can be repeated.'
            cand --without-repos 'Do not use these repositories, a comma-separated list, e.g. cran,bioc. Without a value, do not use any of the project''s repositories, only the ones in --with-repos. Can be repeated.'
            cand --no-index 'Do not use these repositories, a comma-separated list, e.g. cran,bioc. Without a value, do not use any of the project''s repositories, only the ones in --with-repos. Can be repeated.'
            cand --dev 'Include dev (development) dependencies'
            cand --no-base 'Leave out R and the base packages'
            cand --json 'JSON output'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;proj;lock'= {
            cand -r 'R version(s) to solve dependencies for, comma-separated to solve for several (e.g. --r-version 4.5,4.6). Combined with --platform as a cross product, one target per combination. Default: r-versions in [tool.rig] of rproj.toml, or one R version, see --help.'
            cand --r-version 'R version(s) to solve dependencies for, comma-separated to solve for several (e.g. --r-version 4.5,4.6). Combined with --platform as a cross product, one target per combination. Default: r-versions in [tool.rig] of rproj.toml, or one R version, see --help.'
            cand --platform 'Platform(s) to solve binary packages for, e.g. macos, windows, ubuntu-24.04, or a full platform string like aarch64-unknown-linux-gnu-ubuntu-24.04. Comma-separated to solve for several (e.g. --platform macos,windows). Combined with --r-version as a cross product, one target per combination. Use --platform source to solve for source packages only. Default: platforms in [tool.rig] of rproj.toml, or this machine, x86_64-w64-mingw32, x86_64-unknown-linux-gnu, aarch64-apple-darwin and source.'
            cand --add-platform 'Add platform(s) to the set rig would otherwise solve for (rproj.toml''s platforms or the default set), instead of replacing it. Comma-separated, and can be repeated.'
            cand --script 'Lock the inline metadata of this R script into <SCRIPT>.lock, instead of locking the project'
            cand --prefer-binary 'Prefer an older version that has a binary package over a newer one that does not. Optionally give how many of the newest versions to consider, e.g. --prefer-binary=5 (default: 3). Overrides `prefer-binary` in rproj.toml, --prefer-binary=0 turns it off.'
            cand --exclude-newer 'Ignore package versions published after this date. A date (2025-06-01), an RFC 3339 timestamp, or a span back from today (7 days, 2 weeks, P1M). Not before 2017-10-10.'
            cand -P 'Upgrade only these packages, and keep the versions rproj.lock pins for the rest, where they still fit. As <package> or <package>@<version>, e.g. cli or ''cli@>= 3.6.4''. The version is not written to rproj.toml. Comma-separated, and can be repeated.'
            cand --upgrade-package 'Upgrade only these packages, and keep the versions rproj.lock pins for the rest, where they still fit. As <package> or <package>@<version>, e.g. cli or ''cli@>= 3.6.4''. The version is not written to rproj.toml. Comma-separated, and can be repeated.'
            cand --with-repos 'Also use these repositories, a comma-separated list of repository names, URLs or name=URL pairs. Can be repeated.'
            cand --index 'Also use these repositories, a comma-separated list of repository names, URLs or name=URL pairs. Can be repeated.'
            cand --without-repos 'Do not use these repositories, a comma-separated list, e.g. cran,bioc. Without a value, do not use any of the project''s repositories, only the ones in --with-repos. Can be repeated.'
            cand --no-index 'Do not use these repositories, a comma-separated list, e.g. cran,bioc. Without a value, do not use any of the project''s repositories, only the ones in --with-repos. Can be repeated.'
            cand --json 'JSON output'
            cand -U 'Re-resolve every dependency instead of reusing an existing rproj.lock: re-check git/GitHub refs against their remotes, and re-run the solver for CRAN/PPM dependencies instead of keeping a pin that already satisfies rproj.toml.'
            cand --upgrade 'Re-resolve every dependency instead of reusing an existing rproj.lock: re-check git/GitHub refs against their remotes, and re-run the solver for CRAN/PPM dependencies instead of keeping a pin that already satisfies rproj.toml.'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;proj;status'= {
            cand --json 'JSON output'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;proj;sync'= {
            cand --max-concurrent 'Maximum number of concurrent installations (default: number of CPU cores, see ''concurrent-installs'' in ''rig config'')'
            cand --group 'Also install this dependency group, in addition to the default set (main, plus dev unless --no-dev). Repeat or comma-separate for several.'
            cand --extra 'Install this optional-dependency extra. Not installed by default. Repeat or comma-separate for several.'
            cand -r 'Which of rproj.lock''s targets to sync, when more than one matches this machine (default: the highest R version). Selects among the targets already in rproj.lock, does not trigger a new solve.'
            cand --r-version 'Which of rproj.lock''s targets to sync, when more than one matches this machine (default: the highest R version). Selects among the targets already in rproj.lock, does not trigger a new solve.'
            cand --platform 'Which of rproj.lock''s targets to sync, when more than one matches this machine. Selects among the targets already in rproj.lock, does not trigger a new solve. Any spelling of the platform works, e.g. macos for aarch64-apple-darwin.'
            cand --exclude-newer 'Ignore package versions published after this date. A date (2025-06-01), an RFC 3339 timestamp, or a span back from today (7 days, 2 weeks, P1M). Not before 2017-10-10.'
            cand --with-repos 'Also use these repositories, a comma-separated list of repository names, URLs or name=URL pairs. Can be repeated.'
            cand --index 'Also use these repositories, a comma-separated list of repository names, URLs or name=URL pairs. Can be repeated.'
            cand --without-repos 'Do not use these repositories, a comma-separated list, e.g. cran,bioc. Without a value, do not use any of the project''s repositories, only the ones in --with-repos. Can be repeated.'
            cand --no-index 'Do not use these repositories, a comma-separated list, e.g. cran,bioc. Without a value, do not use any of the project''s repositories, only the ones in --with-repos. Can be repeated.'
            cand --no-install-r 'Fail if the R version the lockfile needs is not installed, instead of installing it'
            cand --no-install-project 'Do not install the project''s own package (default: installed when ''type = "package"''). Still installed if another package actually depends on it.'
            cand --no-dev 'Do not install the dev dependency group (default: installed alongside main). An explicit --group dev or --all-groups installs it anyway.'
            cand --all-groups 'Install every dependency group.'
            cand --all-extras 'Install every optional-dependency extra.'
            cand --inexact 'Do not remove packages from the library that are not in rproj.lock (default: remove them)'
            cand --frozen 'Install only from rproj.lock, without touching rproj.toml. Fails if rproj.lock does not exist, instead of creating it.'
            cand --dry-run 'Show what sync would do, without installing, removing or writing anything'
            cand --sysreqs 'Install the system packages the R packages need, even if the sysreqs setting turns this off'
            cand --no-sysreqs 'Do not install the system packages the R packages need'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;proj;renv'= {
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
            cand export 'Write an renv.lock file from rproj.toml'
            cand import 'Create rproj.toml from an renv.lock file'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'rig;proj;renv;export'= {
            cand -r 'R version to solve dependencies for (default: same logic as `rig proj lock`)'
            cand --r-version 'R version to solve dependencies for (default: same logic as `rig proj lock`)'
            cand --platform 'Platform to solve binary packages for, e.g. macos, windows, ubuntu-24.04 (default: this machine). Use --platform source to solve for source packages only.'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;proj;renv;import'= {
            cand -i 'renv.lock file to import (e.g. renv.lock)'
            cand --input 'renv.lock file to import (e.g. renv.lock)'
            cand -r 'R version of the project (default: the version in the renv.lock file)'
            cand --r-version 'R version of the project (default: the version in the renv.lock file)'
            cand --dependencies 'Only merge dependencies, not metadata'
            cand -f 'Overwrite existing project files'
            cand --force 'Overwrite existing project files'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;proj;renv;help'= {
            cand export 'Write an renv.lock file from rproj.toml'
            cand import 'Create rproj.toml from an renv.lock file'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'rig;proj;renv;help;export'= {
        }
        &'rig;proj;renv;help;import'= {
        }
        &'rig;proj;renv;help;help'= {
        }
        &'rig;proj;help'= {
            cand init 'Create a new R project'
            cand import 'Create rproj.toml from a DESCRIPTION file'
            cand export 'Create a DESCRIPTION file from rproj.toml'
            cand add 'Add dependencies to rproj.toml'
            cand remove 'Remove dependencies from rproj.toml'
            cand deps 'Show project dependencies'
            cand tree 'Dependency tree of a project'
            cand lock 'Resolve project dependencies and write rproj.lock'
            cand status 'Show the project''s status'
            cand sync 'Install the dependencies rproj.lock resolved'
            cand renv 'Interoperate with renv, R''s package management tool'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'rig;proj;help;init'= {
        }
        &'rig;proj;help;import'= {
        }
        &'rig;proj;help;export'= {
        }
        &'rig;proj;help;add'= {
        }
        &'rig;proj;help;remove'= {
        }
        &'rig;proj;help;deps'= {
        }
        &'rig;proj;help;tree'= {
        }
        &'rig;proj;help;lock'= {
        }
        &'rig;proj;help;status'= {
        }
        &'rig;proj;help;sync'= {
        }
        &'rig;proj;help;renv'= {
            cand export 'Write an renv.lock file from rproj.toml'
            cand import 'Create rproj.toml from an renv.lock file'
        }
        &'rig;proj;help;renv;export'= {
        }
        &'rig;proj;help;renv;import'= {
        }
        &'rig;proj;help;help'= {
        }
        &'rig;pkg'= {
            cand --json 'JSON output'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
            cand available 'List packages available in the R package repositories'
            cand deps 'Dependencies of a package in the repositories'
            cand doctor 'Find problems with the packages in a library'
            cand info 'Information about a package in the repositories'
            cand install 'Install packages from the repositories'
            cand list 'Packages installed in a library'
            cand remove 'Remove packages from a library'
            cand search 'Search for CRAN packages'
            cand tree 'Dependency tree of a package in the repositories'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'rig;pkg;available'= {
            cand -r 'R version whose repositories to use, instead of the default'
            cand --r-version 'R version whose repositories to use, instead of the default'
            cand --with-repos 'Also use these repositories, a comma-separated list of repository names, URLs or name=URL pairs. Can be repeated.'
            cand --index 'Also use these repositories, a comma-separated list of repository names, URLs or name=URL pairs. Can be repeated.'
            cand --without-repos 'Do not use these repositories, a comma-separated list. Without a value, do not use any of the configured repositories, only the ones in --with-repos. Can be repeated.'
            cand --no-index 'Do not use these repositories, a comma-separated list. Without a value, do not use any of the configured repositories, only the ones in --with-repos. Can be repeated.'
            cand --json 'JSON output'
            cand --include-archived 'Also list packages CRAN has archived'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;pkg;deps'= {
            cand --r-version 'R version whose repositories to use, instead of the default'
            cand --with-repos 'Also use these repositories, a comma-separated list of repository names, URLs or name=URL pairs. Can be repeated.'
            cand --index 'Also use these repositories, a comma-separated list of repository names, URLs or name=URL pairs. Can be repeated.'
            cand --without-repos 'Do not use these repositories, a comma-separated list. Without a value, do not use any of the configured repositories, only the ones in --with-repos. Can be repeated.'
            cand --no-index 'Do not use these repositories, a comma-separated list. Without a value, do not use any of the configured repositories, only the ones in --with-repos. Can be repeated.'
            cand -v 'package version to use (default: latest)'
            cand --version 'package version to use (default: latest)'
            cand -r 'Show recursive (transitive) dependencies'
            cand --recursive 'Show recursive (transitive) dependencies'
            cand --dev 'Include dev (development) dependencies'
            cand --json 'JSON output'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;pkg;doctor'= {
            cand -l 'Library name or path, instead of the default library'
            cand --library 'Library name or path, instead of the default library'
            cand -r 'R version to operate on, instead of the default'
            cand --r-version 'R version to operate on, instead of the default'
            cand --dev 'Also check the Suggests and Enhances dependencies'
            cand --stale 'Warn about packages that rig did not install, if a LinkingTo dependency was built after them'
            cand --json 'JSON output'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;pkg;info'= {
            cand -r 'R version whose repositories to use, instead of the default'
            cand --r-version 'R version whose repositories to use, instead of the default'
            cand --with-repos 'Also use these repositories, a comma-separated list of repository names, URLs or name=URL pairs. Can be repeated.'
            cand --index 'Also use these repositories, a comma-separated list of repository names, URLs or name=URL pairs. Can be repeated.'
            cand --without-repos 'Do not use these repositories, a comma-separated list. Without a value, do not use any of the configured repositories, only the ones in --with-repos. Can be repeated.'
            cand --no-index 'Do not use these repositories, a comma-separated list. Without a value, do not use any of the configured repositories, only the ones in --with-repos. Can be repeated.'
            cand -v 'package version to show (default: latest)'
            cand --version 'package version to show (default: latest)'
            cand --versions 'List all versions of the package, instead of the details of one'
            cand --readme 'Show the README of the package, instead of its metadata'
            cand --json 'JSON output'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;pkg;install'= {
            cand -l 'Library name or path, instead of the default library'
            cand --library 'Library name or path, instead of the default library'
            cand -r 'R version to operate on, instead of the default'
            cand --r-version 'R version to operate on, instead of the default'
            cand --platform 'Platform to install binary packages for, e.g. macos, windows, ubuntu-24.04, or a full platform string like aarch64-unknown-linux-gnu-ubuntu-24.04 (default: this machine). Use --platform source to install source packages only.'
            cand --prefer-binary 'Prefer an older version that has a binary package over a newer one that does not. Optionally give how many of the newest versions to consider, e.g. --prefer-binary=5 (default: 3).'
            cand --exclude-newer 'Ignore package versions published after this date. A date (2025-06-01), an RFC 3339 timestamp, or a span back from today (7 days, 2 weeks, P1M). Not before 2017-10-10.'
            cand --with-repos 'Also use these repositories, a comma-separated list of repository names, URLs or name=URL pairs. Can be repeated.'
            cand --index 'Also use these repositories, a comma-separated list of repository names, URLs or name=URL pairs. Can be repeated.'
            cand --without-repos 'Do not use these repositories, a comma-separated list. Without a value, do not use any of the configured repositories, only the ones in --with-repos. Can be repeated.'
            cand --no-index 'Do not use these repositories, a comma-separated list. Without a value, do not use any of the configured repositories, only the ones in --with-repos. Can be repeated.'
            cand --reinstall 'Install the packages even if they are already up to date'
            cand --dry-run 'Show what would be installed, install nothing'
            cand --sysreqs 'Install the system packages the R packages need, even if the sysreqs setting turns this off'
            cand --no-sysreqs 'Do not install the system packages the R packages need'
            cand --dev 'Include dev (development) dependencies'
            cand --ignore-unavailable 'Skip dev dependencies that are not available in the repositories, instead of failing'
            cand --no-install-project 'Do not install the packages named on the command line, only their dependencies. A named package is still installed if another package that is installed depends on it.'
            cand --json 'JSON output'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;pkg;list'= {
            cand -l 'Library name or path, instead of the default library'
            cand --library 'Library name or path, instead of the default library'
            cand -r 'R version to operate on, instead of the default'
            cand --r-version 'R version to operate on, instead of the default'
            cand --json 'JSON output'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;pkg;remove'= {
            cand -l 'Library name or path, instead of the default library'
            cand --library 'Library name or path, instead of the default library'
            cand -r 'R version to operate on, instead of the default'
            cand --r-version 'R version to operate on, instead of the default'
            cand --force 'Remove base packages as well, which R itself needs'
            cand --json 'JSON output'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;pkg;search'= {
            cand --from 'Rank of the first result to show'
            cand -n 'Number of results to show [default: 8, or 20 with --short]'
            cand --size 'Number of results to show [default: 8, or 20 with --short]'
            cand -s 'Short output, one line per package'
            cand --short 'Short output, one line per package'
            cand --json 'JSON output'
            cand --user 'user'
            cand --admin 'admin'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;pkg;tree'= {
            cand -r 'R version whose repositories to use, instead of the default'
            cand --r-version 'R version whose repositories to use, instead of the default'
            cand --with-repos 'Also use these repositories, a comma-separated list of repository names, URLs or name=URL pairs. Can be repeated.'
            cand --index 'Also use these repositories, a comma-separated list of repository names, URLs or name=URL pairs. Can be repeated.'
            cand --without-repos 'Do not use these repositories, a comma-separated list. Without a value, do not use any of the configured repositories, only the ones in --with-repos. Can be repeated.'
            cand --no-index 'Do not use these repositories, a comma-separated list. Without a value, do not use any of the configured repositories, only the ones in --with-repos. Can be repeated.'
            cand -v 'package version to use (default: latest)'
            cand --version 'package version to use (default: latest)'
            cand --why 'Invert the tree: show what pulls this package in'
            cand --explain 'Invert the tree: show what pulls this package in'
            cand --dev 'Include dev (development) dependencies'
            cand --no-base 'Leave out R and the base packages'
            cand --json 'JSON output'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;pkg;help'= {
            cand available 'List packages available in the R package repositories'
            cand deps 'Dependencies of a package in the repositories'
            cand doctor 'Find problems with the packages in a library'
            cand info 'Information about a package in the repositories'
            cand install 'Install packages from the repositories'
            cand list 'Packages installed in a library'
            cand remove 'Remove packages from a library'
            cand search 'Search for CRAN packages'
            cand tree 'Dependency tree of a package in the repositories'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'rig;pkg;help;available'= {
        }
        &'rig;pkg;help;deps'= {
        }
        &'rig;pkg;help;doctor'= {
        }
        &'rig;pkg;help;info'= {
        }
        &'rig;pkg;help;install'= {
        }
        &'rig;pkg;help;list'= {
        }
        &'rig;pkg;help;remove'= {
        }
        &'rig;pkg;help;search'= {
        }
        &'rig;pkg;help;tree'= {
        }
        &'rig;pkg;help;help'= {
        }
        &'rig;ppm'= {
            cand --json 'JSON output'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
            cand builds 'List the published builds of a package'
            cand build-log 'Show the PPM build log for a package'
            cand platforms 'List the platforms Posit Package Manager builds for'
            cand r-versions 'List the R versions Posit Package Manager builds for'
            cand status 'Show the Posit Package Manager status report'
            cand url 'Print the Posit Package Manager URL'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'rig;ppm;builds'= {
            cand -v 'package version to list (default: all)'
            cand --version 'package version to list (default: all)'
            cand --json 'JSON output'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;ppm;build-log'= {
            cand -p 'P3M build target, e.g. macos, windows, jammy (see `rig ppm builds`); default: the current platform'
            cand --platform 'P3M build target, e.g. macos, windows, jammy (see `rig ppm builds`); default: the current platform'
            cand -r 'R version the build is for (default: the default R version)'
            cand --r-version 'R version the build is for (default: the default R version)'
            cand -a 'CPU architecture (default: the current architecture)'
            cand --arch 'CPU architecture (default: the current architecture)'
            cand -v 'package version (default: latest)'
            cand --version 'package version (default: latest)'
            cand --json 'JSON output'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;ppm;platforms'= {
            cand --all 'Also list the platforms P3M has retired'
            cand --json 'JSON output'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;ppm;r-versions'= {
            cand --json 'JSON output'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;ppm;status'= {
            cand --json 'JSON output'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;ppm;url'= {
            cand --json 'JSON output'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;ppm;help'= {
            cand builds 'List the published builds of a package'
            cand build-log 'Show the PPM build log for a package'
            cand platforms 'List the platforms Posit Package Manager builds for'
            cand r-versions 'List the R versions Posit Package Manager builds for'
            cand status 'Show the Posit Package Manager status report'
            cand url 'Print the Posit Package Manager URL'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'rig;ppm;help;builds'= {
        }
        &'rig;ppm;help;build-log'= {
        }
        &'rig;ppm;help;platforms'= {
        }
        &'rig;ppm;help;r-versions'= {
        }
        &'rig;ppm;help;status'= {
        }
        &'rig;ppm;help;url'= {
        }
        &'rig;ppm;help;help'= {
        }
        &'rig;repos'= {
            cand --json 'JSON output'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
            cand add 'Add a custom R package repository'
            cand disable 'Disable R package repositories for an R version'
            cand enable 'Enable R package repositories for an R version'
            cand list 'List configured R package repositories'
            cand available 'List available R package repositories'
            cand status 'Check the configured R package repositories'
            cand rm 'Remove a custom R package repository'
            cand setup 'Set up R package repositories'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'rig;repos;add'= {
            cand --title 'Short title of the repository'
            cand --description 'Longer description of the repository'
            cand -r 'With --enable, R version to enable the repository for (default: the default R version), can be repeated'
            cand --r-version 'With --enable, R version to enable the repository for (default: the default R version), can be repeated'
            cand --force 'Replace the repository if it already exists'
            cand --enable 'Also enable the repository, see `rig repos enable`'
            cand --all-versions 'With --enable, enable the repository for all R versions, also the ones installed later'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;repos;disable'= {
            cand -r 'R version to disable the repositories for (default: the default R version), can be repeated'
            cand --r-version 'R version to disable the repositories for (default: the default R version), can be repeated'
            cand --all-versions 'Disable the repositories for all installed R versions'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;repos;enable'= {
            cand -r 'R version to enable the repositories for (default: the default R version), can be repeated'
            cand --r-version 'R version to enable the repositories for (default: the default R version), can be repeated'
            cand --all-versions 'Enable the repositories for all installed R versions'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;repos;list'= {
            cand -r 'R version to list repositories for, instead of the default'
            cand --r-version 'R version to list repositories for, instead of the default'
            cand --json 'JSON output'
            cand --all 'Show all repositories, not just the enabled ones'
            cand --raw 'Do not resolve `%` variables in repository URLs.'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;repos;available'= {
            cand --json 'JSON output'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;repos;status'= {
            cand -r 'R version to check repositories for, instead of the default'
            cand --r-version 'R version to check repositories for, instead of the default'
            cand --json 'JSON output'
            cand --all 'Check all repositories, not just the enabled ones'
            cand --raw 'Show repository URLs without resolving `%` variables.'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;repos;rm'= {
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;repos;setup'= {
            cand -r 'R version to set up repositories for (default: all)'
            cand --r-version 'R version to set up repositories for (default: all)'
            cand --with-repos 'Repositories to enable, in addition to the ones enabled by default. If --without-repos is also specified (without a value), then only these repositories will be enabled.'
            cand --without-repos 'Do not set up package repositories. Alternatively, specify which ones to skip, a comma-separated list. If --with-repos is also specified, then only the repositories in that argument will be enabled.'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;repos;help'= {
            cand add 'Add a custom R package repository'
            cand disable 'Disable R package repositories for an R version'
            cand enable 'Enable R package repositories for an R version'
            cand list 'List configured R package repositories'
            cand available 'List available R package repositories'
            cand status 'Check the configured R package repositories'
            cand rm 'Remove a custom R package repository'
            cand setup 'Set up R package repositories'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'rig;repos;help;add'= {
        }
        &'rig;repos;help;disable'= {
        }
        &'rig;repos;help;enable'= {
        }
        &'rig;repos;help;list'= {
        }
        &'rig;repos;help;available'= {
        }
        &'rig;repos;help;status'= {
        }
        &'rig;repos;help;rm'= {
        }
        &'rig;repos;help;setup'= {
        }
        &'rig;repos;help;help'= {
        }
        &'rig;default'= {
            cand --json 'JSON output'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;list'= {
            cand --json 'JSON output'
            cand --plain 'plain output, only the version names, one per line'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;add'= {
            cand --with-repos 'Repositories to enable, in addition to the ones enabled by default. If --without-repos is also specified (without a value), then only these repositories will be enabled.'
            cand --without-repos 'Do not set up package repositories. Alternatively, specify which ones to skip, a comma-separated list. If --with-repos is also specified, then only the repositories in that argument will be enabled.'
            cand --pak-version 'pak version to install.'
            cand --platform 'Install the build for this platform, instead of auto-detecting it. Use `linux-portable` to install a portable (glibc/musl) build.'
            cand -a 'Select architecture: arm64 or x86_64'
            cand --arch 'Select architecture: arm64 or x86_64'
            cand --without-cran-mirror 'Do not set the cloud CRAN mirror. Deprecated in favor of --without-repos=cran.'
            cand --without-p3m 'Do not set up P3M. Deprecated in favor of --without-repos=p3m.  [alias: --without-rspm]'
            cand --without-pak 'Do not install pak.'
            cand --reinstall 'Reinstall, even if this R version is already installed.'
            cand --json 'JSON output'
            cand --without-sysreqs 'Do not set up system requirements installation.'
            cand --without-fonts 'Do not download fallback fonts. rig still writes the fontconfig configuration, but R will only see the fonts that are already installed on the system.'
            cand --without-translations 'Do not install translations.'
            cand --with-desktop-icon 'Install a desktop icon.'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;rm'= {
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;self'= {
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
            cand update 'Update rig to the latest release'
            cand uninstall 'Remove the rig installation'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'rig;self;update'= {
            cand --dry-run 'Check for a new version without downloading or installing it'
            cand --pre-release 'Include pre-releases when looking for the latest version'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;self;uninstall'= {
            cand --dry-run 'Show what would be removed, without removing anything'
            cand --force 'Actually remove rig, instead of just showing what would be removed'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;self;help'= {
            cand update 'Update rig to the latest release'
            cand uninstall 'Remove the rig installation'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'rig;self;help;update'= {
        }
        &'rig;self;help;uninstall'= {
        }
        &'rig;self;help;help'= {
        }
        &'rig;system'= {
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
            cand clean-registry 'Clean stale R related entries in the registry'
            cand update-rtools40 'Update Rtools40 MSYS2 packages'
            cand rtools 'Manage Rtools installations'
            cand fix-r-alias 'Make the ''R'' command start R in PowerShell'
            cand script-assoc 'Run .R files with rig from the Windows command line'
            cand make-orthogonal 'Make installed versions orthogonal'
            cand fix-permissions 'Restrict system library permissions to admin'
            cand no-openmp 'Remove OpenMP (-fopenmp) option for Apple compilers'
            cand allow-debugger 'Allow debugging R with lldb and gdb'
            cand allow-debugger-rstudio 'Allow debugging RStudio with lldb and gdb'
            cand allow-core-dumps 'Allow creating core dumps when R crashes'
            cand blas 'Manage the BLAS/LAPACK library used by R'
            cand forget 'Make system forget about R installations'
            cand update-certs 'Download the CA certificate bundle and configure R to use it'
            cand user-mode 'Switch to user mode and clean up admin-mode installations'
            cand clean-admin-r 'Remove all admin-mode R installations and links'
            cand detect-platform 'Detect operating system version and distribution.'
            cand dirs 'Print the directories rig uses'
            cand make-links 'Create R-* quick links'
            cand fix-aliases 'Fix symbolic R-* quick links'
            cand setup-user-lib 'Set up automatic user package libraries [alias: create-lib]'
            cand add-pak 'Install or update pak for an R version'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'rig;system;clean-registry'= {
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;system;update-rtools40'= {
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;system;rtools'= {
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
            cand list 'List installed Rtools versions [alias: ls]'
            cand add 'Install new Rtools version [alias: install]'
            cand rm 'Remove rtools versions [aliases: del, remove, delete]'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'rig;system;rtools;list'= {
            cand --json 'JSON output'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;system;rtools;add'= {
            cand -a 'Architecture to install Rtools for (default: native arch).'
            cand --arch 'Architecture to install Rtools for (default: native arch).'
            cand --json 'JSON output'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;system;rtools;rm'= {
            cand -a 'Architecture of Rtools to remove (default: native arch).'
            cand --arch 'Architecture of Rtools to remove (default: native arch).'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;system;rtools;help'= {
            cand list 'List installed Rtools versions [alias: ls]'
            cand add 'Install new Rtools version [alias: install]'
            cand rm 'Remove rtools versions [aliases: del, remove, delete]'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'rig;system;rtools;help;list'= {
        }
        &'rig;system;rtools;help;add'= {
        }
        &'rig;system;rtools;help;rm'= {
        }
        &'rig;system;rtools;help;help'= {
        }
        &'rig;system;fix-r-alias'= {
            cand --undo 'Remove the block rig added to the PowerShell profile(s).'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;system;script-assoc'= {
            cand --undo 'Remove the association, and restore the previous one.'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;system;make-orthogonal'= {
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;system;fix-permissions'= {
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;system;no-openmp'= {
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;system;allow-debugger'= {
            cand --all 'Update all R versions'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;system;allow-debugger-rstudio'= {
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;system;allow-core-dumps'= {
            cand --all 'Update all R versions'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;system;blas'= {
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
            cand status 'Show which BLAS/LAPACK library R is using'
            cand set 'Switch the BLAS/LAPACK library R uses'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'rig;system;blas;status'= {
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;system;blas;set'= {
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;system;blas;help'= {
            cand status 'Show which BLAS/LAPACK library R is using'
            cand set 'Switch the BLAS/LAPACK library R uses'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'rig;system;blas;help;status'= {
        }
        &'rig;system;blas;help;set'= {
        }
        &'rig;system;blas;help;help'= {
        }
        &'rig;system;forget'= {
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;system;update-certs'= {
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;system;user-mode'= {
            cand --no-reinstall 'Do not reinstall admin-mode R versions in user mode.'
            cand --keep-install 'Keep the admin-mode R installations, do not remove them.'
            cand --keep-links 'Keep the admin-mode quick links, do not remove them.'
            cand --user 'user'
            cand --admin 'admin'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;system;clean-admin-r'= {
            cand --keep-install 'keep-install'
            cand --keep-links 'keep-links'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;system;detect-platform'= {
            cand --json 'JSON output'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;system;dirs'= {
            cand -a 'Architecture of the R installation root (default: native arch).'
            cand --arch 'Architecture of the R installation root (default: native arch).'
            cand --json 'JSON output'
            cand --r 'Print the R installation root only.'
            cand --rtools 'Print the Rtools installation root only.'
            cand --binary 'Print the quick link directory only.'
            cand --data 'Print rig''s data directory only.'
            cand --fonts 'Print the fontconfig directory only.'
            cand --cache 'Print rig''s cache directory only.'
            cand --download 'Print rig''s installer download directory only.'
            cand --log 'Print rig''s log directory only.'
            cand --library-root 'Print the centralized `rig proj` library root only.'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;system;make-links'= {
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;system;fix-aliases'= {
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;system;setup-user-lib'= {
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;system;add-pak'= {
            cand --pak-version 'pak version to install.'
            cand --devel 'Install the development version of pak (deprecated)'
            cand --all 'Install pak for all R versions'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;system;help'= {
            cand clean-registry 'Clean stale R related entries in the registry'
            cand update-rtools40 'Update Rtools40 MSYS2 packages'
            cand rtools 'Manage Rtools installations'
            cand fix-r-alias 'Make the ''R'' command start R in PowerShell'
            cand script-assoc 'Run .R files with rig from the Windows command line'
            cand make-orthogonal 'Make installed versions orthogonal'
            cand fix-permissions 'Restrict system library permissions to admin'
            cand no-openmp 'Remove OpenMP (-fopenmp) option for Apple compilers'
            cand allow-debugger 'Allow debugging R with lldb and gdb'
            cand allow-debugger-rstudio 'Allow debugging RStudio with lldb and gdb'
            cand allow-core-dumps 'Allow creating core dumps when R crashes'
            cand blas 'Manage the BLAS/LAPACK library used by R'
            cand forget 'Make system forget about R installations'
            cand update-certs 'Download the CA certificate bundle and configure R to use it'
            cand user-mode 'Switch to user mode and clean up admin-mode installations'
            cand clean-admin-r 'Remove all admin-mode R installations and links'
            cand detect-platform 'Detect operating system version and distribution.'
            cand dirs 'Print the directories rig uses'
            cand make-links 'Create R-* quick links'
            cand fix-aliases 'Fix symbolic R-* quick links'
            cand setup-user-lib 'Set up automatic user package libraries [alias: create-lib]'
            cand add-pak 'Install or update pak for an R version'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'rig;system;help;clean-registry'= {
        }
        &'rig;system;help;update-rtools40'= {
        }
        &'rig;system;help;rtools'= {
            cand list 'List installed Rtools versions [alias: ls]'
            cand add 'Install new Rtools version [alias: install]'
            cand rm 'Remove rtools versions [aliases: del, remove, delete]'
        }
        &'rig;system;help;rtools;list'= {
        }
        &'rig;system;help;rtools;add'= {
        }
        &'rig;system;help;rtools;rm'= {
        }
        &'rig;system;help;fix-r-alias'= {
        }
        &'rig;system;help;script-assoc'= {
        }
        &'rig;system;help;make-orthogonal'= {
        }
        &'rig;system;help;fix-permissions'= {
        }
        &'rig;system;help;no-openmp'= {
        }
        &'rig;system;help;allow-debugger'= {
        }
        &'rig;system;help;allow-debugger-rstudio'= {
        }
        &'rig;system;help;allow-core-dumps'= {
        }
        &'rig;system;help;blas'= {
            cand status 'Show which BLAS/LAPACK library R is using'
            cand set 'Switch the BLAS/LAPACK library R uses'
        }
        &'rig;system;help;blas;status'= {
        }
        &'rig;system;help;blas;set'= {
        }
        &'rig;system;help;forget'= {
        }
        &'rig;system;help;update-certs'= {
        }
        &'rig;system;help;user-mode'= {
        }
        &'rig;system;help;clean-admin-r'= {
        }
        &'rig;system;help;detect-platform'= {
        }
        &'rig;system;help;dirs'= {
        }
        &'rig;system;help;make-links'= {
        }
        &'rig;system;help;fix-aliases'= {
        }
        &'rig;system;help;setup-user-lib'= {
        }
        &'rig;system;help;add-pak'= {
        }
        &'rig;system;help;help'= {
        }
        &'rig;rtools'= {
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
            cand list 'List installed Rtools versions [alias: ls]'
            cand add 'Install new Rtools version [alias: install]'
            cand rm 'Remove rtools versions [aliases: del, remove, delete]'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'rig;rtools;list'= {
            cand --json 'JSON output'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;rtools;add'= {
            cand -a 'Architecture to install Rtools for (default: native arch).'
            cand --arch 'Architecture to install Rtools for (default: native arch).'
            cand --json 'JSON output'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;rtools;rm'= {
            cand -a 'Architecture of Rtools to remove (default: native arch).'
            cand --arch 'Architecture of Rtools to remove (default: native arch).'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;rtools;help'= {
            cand list 'List installed Rtools versions [alias: ls]'
            cand add 'Install new Rtools version [alias: install]'
            cand rm 'Remove rtools versions [aliases: del, remove, delete]'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'rig;rtools;help;list'= {
        }
        &'rig;rtools;help;add'= {
        }
        &'rig;rtools;help;rm'= {
        }
        &'rig;rtools;help;help'= {
        }
        &'rig;resolve'= {
            cand --platform 'Use this platform, instead of auto-detecting it.'
            cand -a 'Use this architecture, instead of auto-detecting it.'
            cand --arch 'Use this architecture, instead of auto-detecting it.'
            cand --json 'JSON output'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;rstudio'= {
            cand --config-path 'Do not start RStudio, only print the path of the RStudio config directory'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;library'= {
            cand --json 'JSON output'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
            cand list 'List libraries [alias: ls]'
            cand add 'Add a new library'
            cand rm 'Remove a library'
            cand default 'Set the default library'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'rig;library;list'= {
            cand -r 'R version to operate on, instead of the default'
            cand --r-version 'R version to operate on, instead of the default'
            cand --json 'JSON output'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;library;add'= {
            cand -r 'R version to operate on, instead of the default'
            cand --r-version 'R version to operate on, instead of the default'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;library;rm'= {
            cand -r 'R version to operate on, instead of the default'
            cand --r-version 'R version to operate on, instead of the default'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;library;default'= {
            cand -r 'R version to operate on, instead of the default'
            cand --r-version 'R version to operate on, instead of the default'
            cand --json 'JSON output'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;library;help'= {
            cand list 'List libraries [alias: ls]'
            cand add 'Add a new library'
            cand rm 'Remove a library'
            cand default 'Set the default library'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'rig;library;help;list'= {
        }
        &'rig;library;help;add'= {
        }
        &'rig;library;help;rm'= {
        }
        &'rig;library;help;default'= {
        }
        &'rig;library;help;help'= {
        }
        &'rig;cache'= {
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
            cand info 'Show cache size and contents'
            cand clean 'Delete cached files'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'rig;cache;info'= {
            cand --json 'JSON output'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;cache;clean'= {
            cand --category 'Only delete this category of cached files'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;cache;help'= {
            cand info 'Show cache size and contents'
            cand clean 'Delete cached files'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'rig;cache;help;info'= {
        }
        &'rig;cache;help;clean'= {
        }
        &'rig;cache;help;help'= {
        }
        &'rig;available'= {
            cand --platform 'Use this platform, instead of auto-detecting it.'
            cand -a 'Use this architecture, instead of auto-detecting it.'
            cand --arch 'Use this architecture, instead of auto-detecting it.'
            cand --json 'JSON output'
            cand --all 'List all available versions.'
            cand --list-distros 'List supported Linux distributions instead of R versions.'
            cand --list-rtools-versions 'List available Rtools versions instead of R versions.'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;run'= {
            cand -r 'R version to use'
            cand --r-version 'R version to use'
            cand -t 'Explicitly specify app type to run'
            cand --app-type 'Explicitly specify app type to run'
            cand -e 'R expression to evaluate'
            cand --eval 'R expression to evaluate'
            cand -f 'R script file to run'
            cand --script 'R script file to run'
            cand -P 'Upgrade only these packages in the environment of a script with a `# /// script` block. As <package> or <package>@<version>. Comma-separated, and can be repeated.'
            cand --upgrade-package 'Upgrade only these packages in the environment of a script with a `# /// script` block. As <package> or <package>@<version>. Comma-separated, and can be repeated.'
            cand --no-project 'Ignore the project environment, use the default R version'
            cand --dry-run 'Show the command, but do not run it'
            cand --startup 'Print R startup message'
            cand --no-startup 'Do not print R startup message'
            cand --echo 'Print input to R'
            cand --no-echo 'Do not print input to R'
            cand --cmd 'Run `R CMD <command>` with the trailing arguments'
            cand --list 'List the scripts the project declares'
            cand --json 'JSON output'
            cand --activate 'Put the selected R version on PATH for the subprocess'
            cand --shell 'Run a shell instead of R, with the selected R version on PATH'
            cand --rscript 'Run with Rscript instead of R, e.g. for scripts (no echoing of input)'
            cand -U 'Re-resolve every dependency of a script with a `# /// script` block, instead of keeping the versions its environment has'
            cand --upgrade 'Re-resolve every dependency of a script with a `# /// script` block, instead of keeping the versions its environment has'
            cand --locked 'Fail if the lock file of a script (<script>.lock) does not fit its `# /// script` block, instead of updating the lock file'
            cand --user 'Run in user mode (overrides RIG_MODE and config)'
            cand --admin 'Run in admin mode (overrides RIG_MODE and config)'
            cand --no-cache 'Do not read or write rig''s cache (overrides RIG_NO_CACHE and config)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;help'= {
            cand config 'Manage rig configuration'
            cand proj 'Manage R projects (experimental)'
            cand pkg 'Manage R packages (experimental)'
            cand ppm 'Query Posit Package Manager (experimental)'
            cand repos 'Manage package repositories'
            cand default 'Print or set default R version [alias: switch]'
            cand list 'List installed R versions [alias: ls]'
            cand add 'Install a new R version [alias: install]'
            cand rm 'Remove R versions [aliases: del, remove, delete]'
            cand self 'Manage the rig installation itself'
            cand system 'Manage current installations'
            cand rtools 'Manage Rtools installations'
            cand resolve 'Resolve a symbolic R version'
            cand rstudio 'Start RStudio with specified R version'
            cand library 'Manage package libraries [alias: lib]'
            cand cache 'Manage rig''s download cache'
            cand available 'List R versions available to install.'
            cand run 'Run R, an R script or an R project'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'rig;help;config'= {
            cand config-file-path 'Print the path to the rig config file'
            cand list 'List the names of all config entries'
            cand get 'Get a config entry'
            cand set 'Set a config entry'
        }
        &'rig;help;config;config-file-path'= {
        }
        &'rig;help;config;list'= {
        }
        &'rig;help;config;get'= {
        }
        &'rig;help;config;set'= {
        }
        &'rig;help;proj'= {
            cand init 'Create a new R project'
            cand import 'Create rproj.toml from a DESCRIPTION file'
            cand export 'Create a DESCRIPTION file from rproj.toml'
            cand add 'Add dependencies to rproj.toml'
            cand remove 'Remove dependencies from rproj.toml'
            cand deps 'Show project dependencies'
            cand tree 'Dependency tree of a project'
            cand lock 'Resolve project dependencies and write rproj.lock'
            cand status 'Show the project''s status'
            cand sync 'Install the dependencies rproj.lock resolved'
            cand renv 'Interoperate with renv, R''s package management tool'
        }
        &'rig;help;proj;init'= {
        }
        &'rig;help;proj;import'= {
        }
        &'rig;help;proj;export'= {
        }
        &'rig;help;proj;add'= {
        }
        &'rig;help;proj;remove'= {
        }
        &'rig;help;proj;deps'= {
        }
        &'rig;help;proj;tree'= {
        }
        &'rig;help;proj;lock'= {
        }
        &'rig;help;proj;status'= {
        }
        &'rig;help;proj;sync'= {
        }
        &'rig;help;proj;renv'= {
            cand export 'Write an renv.lock file from rproj.toml'
            cand import 'Create rproj.toml from an renv.lock file'
        }
        &'rig;help;proj;renv;export'= {
        }
        &'rig;help;proj;renv;import'= {
        }
        &'rig;help;pkg'= {
            cand available 'List packages available in the R package repositories'
            cand deps 'Dependencies of a package in the repositories'
            cand doctor 'Find problems with the packages in a library'
            cand info 'Information about a package in the repositories'
            cand install 'Install packages from the repositories'
            cand list 'Packages installed in a library'
            cand remove 'Remove packages from a library'
            cand search 'Search for CRAN packages'
            cand tree 'Dependency tree of a package in the repositories'
        }
        &'rig;help;pkg;available'= {
        }
        &'rig;help;pkg;deps'= {
        }
        &'rig;help;pkg;doctor'= {
        }
        &'rig;help;pkg;info'= {
        }
        &'rig;help;pkg;install'= {
        }
        &'rig;help;pkg;list'= {
        }
        &'rig;help;pkg;remove'= {
        }
        &'rig;help;pkg;search'= {
        }
        &'rig;help;pkg;tree'= {
        }
        &'rig;help;ppm'= {
            cand builds 'List the published builds of a package'
            cand build-log 'Show the PPM build log for a package'
            cand platforms 'List the platforms Posit Package Manager builds for'
            cand r-versions 'List the R versions Posit Package Manager builds for'
            cand status 'Show the Posit Package Manager status report'
            cand url 'Print the Posit Package Manager URL'
        }
        &'rig;help;ppm;builds'= {
        }
        &'rig;help;ppm;build-log'= {
        }
        &'rig;help;ppm;platforms'= {
        }
        &'rig;help;ppm;r-versions'= {
        }
        &'rig;help;ppm;status'= {
        }
        &'rig;help;ppm;url'= {
        }
        &'rig;help;repos'= {
            cand add 'Add a custom R package repository'
            cand disable 'Disable R package repositories for an R version'
            cand enable 'Enable R package repositories for an R version'
            cand list 'List configured R package repositories'
            cand available 'List available R package repositories'
            cand status 'Check the configured R package repositories'
            cand rm 'Remove a custom R package repository'
            cand setup 'Set up R package repositories'
        }
        &'rig;help;repos;add'= {
        }
        &'rig;help;repos;disable'= {
        }
        &'rig;help;repos;enable'= {
        }
        &'rig;help;repos;list'= {
        }
        &'rig;help;repos;available'= {
        }
        &'rig;help;repos;status'= {
        }
        &'rig;help;repos;rm'= {
        }
        &'rig;help;repos;setup'= {
        }
        &'rig;help;default'= {
        }
        &'rig;help;list'= {
        }
        &'rig;help;add'= {
        }
        &'rig;help;rm'= {
        }
        &'rig;help;self'= {
            cand update 'Update rig to the latest release'
            cand uninstall 'Remove the rig installation'
        }
        &'rig;help;self;update'= {
        }
        &'rig;help;self;uninstall'= {
        }
        &'rig;help;system'= {
            cand clean-registry 'Clean stale R related entries in the registry'
            cand update-rtools40 'Update Rtools40 MSYS2 packages'
            cand rtools 'Manage Rtools installations'
            cand fix-r-alias 'Make the ''R'' command start R in PowerShell'
            cand script-assoc 'Run .R files with rig from the Windows command line'
            cand make-orthogonal 'Make installed versions orthogonal'
            cand fix-permissions 'Restrict system library permissions to admin'
            cand no-openmp 'Remove OpenMP (-fopenmp) option for Apple compilers'
            cand allow-debugger 'Allow debugging R with lldb and gdb'
            cand allow-debugger-rstudio 'Allow debugging RStudio with lldb and gdb'
            cand allow-core-dumps 'Allow creating core dumps when R crashes'
            cand blas 'Manage the BLAS/LAPACK library used by R'
            cand forget 'Make system forget about R installations'
            cand update-certs 'Download the CA certificate bundle and configure R to use it'
            cand user-mode 'Switch to user mode and clean up admin-mode installations'
            cand clean-admin-r 'Remove all admin-mode R installations and links'
            cand detect-platform 'Detect operating system version and distribution.'
            cand dirs 'Print the directories rig uses'
            cand make-links 'Create R-* quick links'
            cand fix-aliases 'Fix symbolic R-* quick links'
            cand setup-user-lib 'Set up automatic user package libraries [alias: create-lib]'
            cand add-pak 'Install or update pak for an R version'
        }
        &'rig;help;system;clean-registry'= {
        }
        &'rig;help;system;update-rtools40'= {
        }
        &'rig;help;system;rtools'= {
            cand list 'List installed Rtools versions [alias: ls]'
            cand add 'Install new Rtools version [alias: install]'
            cand rm 'Remove rtools versions [aliases: del, remove, delete]'
        }
        &'rig;help;system;rtools;list'= {
        }
        &'rig;help;system;rtools;add'= {
        }
        &'rig;help;system;rtools;rm'= {
        }
        &'rig;help;system;fix-r-alias'= {
        }
        &'rig;help;system;script-assoc'= {
        }
        &'rig;help;system;make-orthogonal'= {
        }
        &'rig;help;system;fix-permissions'= {
        }
        &'rig;help;system;no-openmp'= {
        }
        &'rig;help;system;allow-debugger'= {
        }
        &'rig;help;system;allow-debugger-rstudio'= {
        }
        &'rig;help;system;allow-core-dumps'= {
        }
        &'rig;help;system;blas'= {
            cand status 'Show which BLAS/LAPACK library R is using'
            cand set 'Switch the BLAS/LAPACK library R uses'
        }
        &'rig;help;system;blas;status'= {
        }
        &'rig;help;system;blas;set'= {
        }
        &'rig;help;system;forget'= {
        }
        &'rig;help;system;update-certs'= {
        }
        &'rig;help;system;user-mode'= {
        }
        &'rig;help;system;clean-admin-r'= {
        }
        &'rig;help;system;detect-platform'= {
        }
        &'rig;help;system;dirs'= {
        }
        &'rig;help;system;make-links'= {
        }
        &'rig;help;system;fix-aliases'= {
        }
        &'rig;help;system;setup-user-lib'= {
        }
        &'rig;help;system;add-pak'= {
        }
        &'rig;help;rtools'= {
            cand list 'List installed Rtools versions [alias: ls]'
            cand add 'Install new Rtools version [alias: install]'
            cand rm 'Remove rtools versions [aliases: del, remove, delete]'
        }
        &'rig;help;rtools;list'= {
        }
        &'rig;help;rtools;add'= {
        }
        &'rig;help;rtools;rm'= {
        }
        &'rig;help;resolve'= {
        }
        &'rig;help;rstudio'= {
        }
        &'rig;help;library'= {
            cand list 'List libraries [alias: ls]'
            cand add 'Add a new library'
            cand rm 'Remove a library'
            cand default 'Set the default library'
        }
        &'rig;help;library;list'= {
        }
        &'rig;help;library;add'= {
        }
        &'rig;help;library;rm'= {
        }
        &'rig;help;library;default'= {
        }
        &'rig;help;cache'= {
            cand info 'Show cache size and contents'
            cand clean 'Delete cached files'
        }
        &'rig;help;cache;info'= {
        }
        &'rig;help;cache;clean'= {
        }
        &'rig;help;available'= {
        }
        &'rig;help;run'= {
        }
        &'rig;help;help'= {
        }
    ]
    $completions[$command]
}
