# Print an optspec for argparse to handle cmd's options that are independent of any subcommand.
function __fish_rig_global_optspecs
	string join \n q/quiet v/verbose json user admin no-cache cache-dir= h/help V/version
end

function __fish_rig_needs_command
	# Figure out if the current invocation already has a command.
	set -l cmd (commandline -opc)
	set -e cmd[1]
	argparse -s (__fish_rig_global_optspecs) -- $cmd 2>/dev/null
	or return
	if set -q argv[1]
		# Also print the command, so this can be used to figure out what it is.
		echo $argv[1]
		return 1
	end
	return 0
end

function __fish_rig_using_subcommand
	set -l cmd (__fish_rig_needs_command)
	test -z "$cmd"
	and return 1
	contains -- $cmd[1] $argv
end

complete -c rig -n "__fish_rig_needs_command" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_needs_command" -s q -l quiet -d 'Suppress output (overrides `--verbose`)'
complete -c rig -n "__fish_rig_needs_command" -s v -l verbose -d 'Verbose output'
complete -c rig -n "__fish_rig_needs_command" -l json -d 'Output JSON'
complete -c rig -n "__fish_rig_needs_command" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_needs_command" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_needs_command" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_needs_command" -s h -l help -d 'Print help'
complete -c rig -n "__fish_rig_needs_command" -s V -l version -d 'Print version'
complete -c rig -n "__fish_rig_needs_command" -f -a "config" -d 'Manage rig configuration'
complete -c rig -n "__fish_rig_needs_command" -f -a "proj" -d 'Manage R projects (experimental)'
complete -c rig -n "__fish_rig_needs_command" -f -a "pkg" -d 'Manage R packages (experimental)'
complete -c rig -n "__fish_rig_needs_command" -f -a "ppm" -d 'Query Posit Package Manager (experimental)'
complete -c rig -n "__fish_rig_needs_command" -f -a "auth" -d 'Manage credentials for repositories and Package Manager instances'
complete -c rig -n "__fish_rig_needs_command" -f -a "repos" -d 'Manage package repositories'
complete -c rig -n "__fish_rig_needs_command" -f -a "default" -d 'Print or set default R version [alias: switch]'
complete -c rig -n "__fish_rig_needs_command" -f -a "list" -d 'List installed R versions [alias: ls]'
complete -c rig -n "__fish_rig_needs_command" -f -a "add" -d 'Install a new R version [alias: install]'
complete -c rig -n "__fish_rig_needs_command" -f -a "rm" -d 'Remove R versions [aliases: del, remove, delete]'
complete -c rig -n "__fish_rig_needs_command" -f -a "self" -d 'Manage the rig installation itself'
complete -c rig -n "__fish_rig_needs_command" -f -a "system" -d 'Manage current installations'
complete -c rig -n "__fish_rig_needs_command" -f -a "rtools" -d 'Manage Rtools installations'
complete -c rig -n "__fish_rig_needs_command" -f -a "resolve" -d 'Resolve a symbolic R version'
complete -c rig -n "__fish_rig_needs_command" -f -a "rstudio" -d 'Start RStudio with specified R version'
complete -c rig -n "__fish_rig_needs_command" -f -a "library" -d 'Manage package libraries [alias: lib]'
complete -c rig -n "__fish_rig_needs_command" -f -a "cache" -d 'Manage rig\'s download cache'
complete -c rig -n "__fish_rig_needs_command" -f -a "available" -d 'List R versions available to install.'
complete -c rig -n "__fish_rig_needs_command" -f -a "run" -d 'Run R, an R script or an R project'
complete -c rig -n "__fish_rig_needs_command" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rig -n "__fish_rig_using_subcommand config; and not __fish_seen_subcommand_from config-file-path list get set help" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand config; and not __fish_seen_subcommand_from config-file-path list get set help" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand config; and not __fish_seen_subcommand_from config-file-path list get set help" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand config; and not __fish_seen_subcommand_from config-file-path list get set help" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand config; and not __fish_seen_subcommand_from config-file-path list get set help" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand config; and not __fish_seen_subcommand_from config-file-path list get set help" -f -a "config-file-path" -d 'Print the path to the rig config file'
complete -c rig -n "__fish_rig_using_subcommand config; and not __fish_seen_subcommand_from config-file-path list get set help" -f -a "list" -d 'List the names of all config entries'
complete -c rig -n "__fish_rig_using_subcommand config; and not __fish_seen_subcommand_from config-file-path list get set help" -f -a "get" -d 'Get a config entry'
complete -c rig -n "__fish_rig_using_subcommand config; and not __fish_seen_subcommand_from config-file-path list get set help" -f -a "set" -d 'Set a config entry'
complete -c rig -n "__fish_rig_using_subcommand config; and not __fish_seen_subcommand_from config-file-path list get set help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rig -n "__fish_rig_using_subcommand config; and __fish_seen_subcommand_from config-file-path" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand config; and __fish_seen_subcommand_from config-file-path" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand config; and __fish_seen_subcommand_from config-file-path" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand config; and __fish_seen_subcommand_from config-file-path" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand config; and __fish_seen_subcommand_from config-file-path" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand config; and __fish_seen_subcommand_from list" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand config; and __fish_seen_subcommand_from list" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand config; and __fish_seen_subcommand_from list" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand config; and __fish_seen_subcommand_from list" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand config; and __fish_seen_subcommand_from list" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand config; and __fish_seen_subcommand_from list" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand config; and __fish_seen_subcommand_from get" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand config; and __fish_seen_subcommand_from get" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand config; and __fish_seen_subcommand_from get" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand config; and __fish_seen_subcommand_from get" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand config; and __fish_seen_subcommand_from get" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand config; and __fish_seen_subcommand_from get" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand config; and __fish_seen_subcommand_from set" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand config; and __fish_seen_subcommand_from set" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand config; and __fish_seen_subcommand_from set" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand config; and __fish_seen_subcommand_from set" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand config; and __fish_seen_subcommand_from set" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand config; and __fish_seen_subcommand_from help" -f -a "config-file-path" -d 'Print the path to the rig config file'
complete -c rig -n "__fish_rig_using_subcommand config; and __fish_seen_subcommand_from help" -f -a "list" -d 'List the names of all config entries'
complete -c rig -n "__fish_rig_using_subcommand config; and __fish_seen_subcommand_from help" -f -a "get" -d 'Get a config entry'
complete -c rig -n "__fish_rig_using_subcommand config; and __fish_seen_subcommand_from help" -f -a "set" -d 'Set a config entry'
complete -c rig -n "__fish_rig_using_subcommand config; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rig -n "__fish_rig_using_subcommand proj; and not __fish_seen_subcommand_from init import export add remove deps tree lock status sync renv help" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand proj; and not __fish_seen_subcommand_from init import export add remove deps tree lock status sync renv help" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand proj; and not __fish_seen_subcommand_from init import export add remove deps tree lock status sync renv help" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand proj; and not __fish_seen_subcommand_from init import export add remove deps tree lock status sync renv help" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand proj; and not __fish_seen_subcommand_from init import export add remove deps tree lock status sync renv help" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand proj; and not __fish_seen_subcommand_from init import export add remove deps tree lock status sync renv help" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand proj; and not __fish_seen_subcommand_from init import export add remove deps tree lock status sync renv help" -f -a "init" -d 'Create a new R project'
complete -c rig -n "__fish_rig_using_subcommand proj; and not __fish_seen_subcommand_from init import export add remove deps tree lock status sync renv help" -f -a "import" -d 'Create rproj.toml from a DESCRIPTION file'
complete -c rig -n "__fish_rig_using_subcommand proj; and not __fish_seen_subcommand_from init import export add remove deps tree lock status sync renv help" -f -a "export" -d 'Create a DESCRIPTION file from rproj.toml'
complete -c rig -n "__fish_rig_using_subcommand proj; and not __fish_seen_subcommand_from init import export add remove deps tree lock status sync renv help" -f -a "add" -d 'Add dependencies to rproj.toml'
complete -c rig -n "__fish_rig_using_subcommand proj; and not __fish_seen_subcommand_from init import export add remove deps tree lock status sync renv help" -f -a "remove" -d 'Remove dependencies from rproj.toml'
complete -c rig -n "__fish_rig_using_subcommand proj; and not __fish_seen_subcommand_from init import export add remove deps tree lock status sync renv help" -f -a "deps" -d 'Show project dependencies'
complete -c rig -n "__fish_rig_using_subcommand proj; and not __fish_seen_subcommand_from init import export add remove deps tree lock status sync renv help" -f -a "tree" -d 'Dependency tree of a project'
complete -c rig -n "__fish_rig_using_subcommand proj; and not __fish_seen_subcommand_from init import export add remove deps tree lock status sync renv help" -f -a "lock" -d 'Resolve project dependencies and write rproj.lock'
complete -c rig -n "__fish_rig_using_subcommand proj; and not __fish_seen_subcommand_from init import export add remove deps tree lock status sync renv help" -f -a "status" -d 'Show the project\'s status'
complete -c rig -n "__fish_rig_using_subcommand proj; and not __fish_seen_subcommand_from init import export add remove deps tree lock status sync renv help" -f -a "sync" -d 'Install the dependencies rproj.lock resolved'
complete -c rig -n "__fish_rig_using_subcommand proj; and not __fish_seen_subcommand_from init import export add remove deps tree lock status sync renv help" -f -a "renv" -d 'Interoperate with renv, R\'s package management tool'
complete -c rig -n "__fish_rig_using_subcommand proj; and not __fish_seen_subcommand_from init import export add remove deps tree lock status sync renv help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from init" -s r -l r-version -d 'R version of the project (default: the default R version, or the current R release)' -r
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from init" -l script -d 'Create the inline metadata block of this R script, instead of a project' -r
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from init" -l prefer-binary -d 'Write `prefer-binary` into the [tool.rig] table of the manifest, see `rig proj lock --prefer-binary`. Optionally give how many of the newest versions to consider, e.g. --prefer-binary=5 (default: 3). --prefer-binary=0 writes `prefer-binary = false`.' -r
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from init" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from init" -s f -l force -d 'Overwrite existing project files'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from init" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from init" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from init" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from init" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from import" -s i -l input -d 'DESCRIPTION file to import (e.g. DESCRIPTION)' -r
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from import" -s r -l r-version -d 'R version of the project (default: the version the DESCRIPTION file requires, the default R version, or the current R release)' -r
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from import" -l prefer-binary -d 'Write `prefer-binary` into the [tool.rig] table of the manifest, see `rig proj lock --prefer-binary`. Optionally give how many of the newest versions to consider, e.g. --prefer-binary=5 (default: 3). --prefer-binary=0 writes `prefer-binary = false`.' -r
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from import" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from import" -l dependencies -d 'Only merge dependencies, not metadata (the old behavior)'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from import" -s f -l force -d 'Overwrite existing project files'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from import" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from import" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from import" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from import" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from export" -s o -l output -d 'Output file to write (e.g. DESCRIPTION)' -r
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from export" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from export" -s f -l force -d 'Overwrite the output file if it already exists'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from export" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from export" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from export" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from export" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from add" -l script -d 'Add the packages to the inline metadata of this R script, instead of rproj.toml' -r
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from add" -l with-repos -l index -d 'Add the packages from this repository: a repository name, URL or name=URL pair. A new repository is added to rproj.toml, and the packages are pinned to the first one. Comma-separated, and can be repeated.' -r
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from add" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from add" -l dev -d 'Add as a dev (development) dependency'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from add" -l no-lock -d 'Only update rproj.toml, do not update rproj.lock'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from add" -l no-sync -d 'Do not install the added packages'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from add" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from add" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from add" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from add" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from remove" -l script -d 'Remove the packages from the inline metadata of this R script, instead of rproj.toml' -r
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from remove" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from remove" -l no-lock -d 'Only update rproj.toml, do not update rproj.lock'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from remove" -l no-sync -d 'Do not re-sync the project library'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from remove" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from remove" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from remove" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from remove" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from deps" -l with-repos -l index -d 'Also use these repositories, a comma-separated list of repository names, URLs or name=URL pairs. Can be repeated.' -r
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from deps" -l without-repos -l no-index -d 'Do not use these repositories, a comma-separated list, given with \'=\', e.g. --without-repos=cran,bioc. Without a value, do not use any of the project\'s repositories, only the ones in --with-repos. Can be repeated.' -r
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from deps" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from deps" -s r -l recursive -d 'Show recursive (transitive) dependencies'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from deps" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from deps" -l dev -d 'Include dev (development) dependencies'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from deps" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from deps" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from deps" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from deps" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from tree" -l why -l explain -d 'Invert the tree: show what pulls this package in' -r
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from tree" -l with-repos -l index -d 'Also use these repositories, a comma-separated list of repository names, URLs or name=URL pairs. Can be repeated.' -r
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from tree" -l without-repos -l no-index -d 'Do not use these repositories, a comma-separated list, given with \'=\', e.g. --without-repos=cran,bioc. Without a value, do not use any of the project\'s repositories, only the ones in --with-repos. Can be repeated.' -r
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from tree" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from tree" -l dev -d 'Include dev (development) dependencies'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from tree" -l no-base -d 'Leave out R and the base packages'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from tree" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from tree" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from tree" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from tree" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from tree" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from lock" -s r -l r-version -d 'R version(s) to solve dependencies for, comma-separated to solve for several (e.g. --r-version 4.5,4.6). Combined with --platform as a cross product, one target per combination. Default: r-versions in [tool.rig] of rproj.toml, or one R version, see --help.' -r
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from lock" -l platform -d 'Platform(s) to solve binary packages for, e.g. macos, windows, ubuntu-24.04, or a full platform string like aarch64-unknown-linux-gnu-ubuntu-24.04. Comma-separated to solve for several (e.g. --platform macos,windows). Combined with --r-version as a cross product, one target per combination. Use --platform source to solve for source packages only. Default: platforms in [tool.rig] of rproj.toml, or this machine, x86_64-w64-mingw32, x86_64-unknown-linux-gnu, aarch64-apple-darwin and source.' -r
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from lock" -l add-platform -d 'Add platform(s) to the set rig would otherwise solve for (rproj.toml\'s platforms or the default set), instead of replacing it. Comma-separated, and can be repeated.' -r
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from lock" -l script -d 'Lock the inline metadata of this R script into <SCRIPT>.lock, instead of locking the project' -r
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from lock" -l prefer-binary -d 'Prefer an older version that has a binary package over a newer one that does not. Optionally give how many of the newest versions to consider, e.g. --prefer-binary=5 (default: 3). Overrides `prefer-binary` in rproj.toml, --prefer-binary=0 turns it off.' -r
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from lock" -l exclude-newer -d 'Ignore package versions published after this date. A date (2025-06-01), an RFC 3339 timestamp, or a span back from today (7 days, 2 weeks, P1M). Not before 2017-10-10.' -r
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from lock" -s P -l upgrade-package -d 'Upgrade only these packages, and keep the versions rproj.lock pins for the rest, where they still fit. As <package> or <package>@<version>, e.g. cli or \'cli@>= 3.6.4\'. The version is not written to rproj.toml. Comma-separated, and can be repeated.' -r
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from lock" -l with-repos -l index -d 'Also use these repositories, a comma-separated list of repository names, URLs or name=URL pairs. Can be repeated.' -r
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from lock" -l without-repos -l no-index -d 'Do not use these repositories, a comma-separated list, given with \'=\', e.g. --without-repos=cran,bioc. Without a value, do not use any of the project\'s repositories, only the ones in --with-repos. Can be repeated.' -r
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from lock" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from lock" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from lock" -s U -l upgrade -d 'Re-resolve every dependency instead of reusing an existing rproj.lock: re-check git/GitHub refs against their remotes, and re-run the solver for CRAN/PPM dependencies instead of keeping a pin that already satisfies rproj.toml.'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from lock" -l check -d 'Check that rproj.lock is up to date with rproj.toml, without writing it. Fails if it is missing or out of date.'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from lock" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from lock" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from lock" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from lock" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from status" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from status" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from status" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from status" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from status" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from status" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from sync" -l max-concurrent -d 'Maximum number of concurrent installations (default: number of CPU cores, see \'concurrent-installs\' in \'rig config\')' -r
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from sync" -l group -d 'Also install this dependency group, in addition to the default set (main, plus dev unless --no-dev). Repeat or comma-separate for several.' -r
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from sync" -l extra -d 'Install this optional-dependency extra. Not installed by default. Repeat or comma-separate for several.' -r
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from sync" -s r -l r-version -d 'Which of rproj.lock\'s targets to sync, when more than one matches this machine (default: the highest R version). Selects among the targets already in rproj.lock, does not trigger a new solve.' -r
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from sync" -l platform -d 'Which of rproj.lock\'s targets to sync, when more than one matches this machine. Selects among the targets already in rproj.lock, does not trigger a new solve. Any spelling of the platform works, e.g. macos for aarch64-apple-darwin.' -r
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from sync" -l exclude-newer -d 'Ignore package versions published after this date. A date (2025-06-01), an RFC 3339 timestamp, or a span back from today (7 days, 2 weeks, P1M). Not before 2017-10-10.' -r
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from sync" -l with-repos -l index -d 'Also use these repositories, a comma-separated list of repository names, URLs or name=URL pairs. Can be repeated.' -r
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from sync" -l without-repos -l no-index -d 'Do not use these repositories, a comma-separated list, given with \'=\', e.g. --without-repos=cran,bioc. Without a value, do not use any of the project\'s repositories, only the ones in --with-repos. Can be repeated.' -r
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from sync" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from sync" -l no-install-r -d 'Fail if the R version the lockfile needs is not installed, instead of installing it'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from sync" -l no-install-project -l no-install-self -d 'Do not install the project\'s own package (default: installed when \'type = "package"\'). Still installed if another package actually depends on it.'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from sync" -l no-dev -d 'Do not install the dev dependency group (default: installed alongside main). An explicit --group dev or --all-groups installs it anyway.'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from sync" -l all-groups -d 'Install every dependency group.'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from sync" -l all-extras -d 'Install every optional-dependency extra.'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from sync" -l inexact -d 'Do not remove packages from the library that are not in rproj.lock (default: remove them)'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from sync" -l frozen -d 'Install only from rproj.lock, without touching rproj.toml. Fails if rproj.lock does not exist, instead of creating it.'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from sync" -l locked -d 'Fail if rproj.lock is missing or out of date with rproj.toml, instead of installing from it.'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from sync" -l dry-run -d 'Show what sync would do, without installing, removing or writing anything'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from sync" -l check -d 'Check that the project environment is in sync with rproj.lock, without changing anything. Fails if sync would install, remove or update anything.'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from sync" -l sysreqs -d 'Install the system packages the R packages need, even if the sysreqs setting turns this off'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from sync" -l no-sysreqs -d 'Do not install the system packages the R packages need'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from sync" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from sync" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from sync" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from sync" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from renv" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from renv" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from renv" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from renv" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from renv" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from renv" -f -a "export" -d 'Write an renv.lock file from rproj.toml'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from renv" -f -a "import" -d 'Create rproj.toml from an renv.lock file'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from renv" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from help" -f -a "init" -d 'Create a new R project'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from help" -f -a "import" -d 'Create rproj.toml from a DESCRIPTION file'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from help" -f -a "export" -d 'Create a DESCRIPTION file from rproj.toml'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from help" -f -a "add" -d 'Add dependencies to rproj.toml'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from help" -f -a "remove" -d 'Remove dependencies from rproj.toml'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from help" -f -a "deps" -d 'Show project dependencies'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from help" -f -a "tree" -d 'Dependency tree of a project'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from help" -f -a "lock" -d 'Resolve project dependencies and write rproj.lock'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from help" -f -a "status" -d 'Show the project\'s status'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from help" -f -a "sync" -d 'Install the dependencies rproj.lock resolved'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from help" -f -a "renv" -d 'Interoperate with renv, R\'s package management tool'
complete -c rig -n "__fish_rig_using_subcommand proj; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rig -n "__fish_rig_using_subcommand pkg; and not __fish_seen_subcommand_from available deps doctor info install list remove search sync tree help" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand pkg; and not __fish_seen_subcommand_from available deps doctor info install list remove search sync tree help" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand pkg; and not __fish_seen_subcommand_from available deps doctor info install list remove search sync tree help" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand pkg; and not __fish_seen_subcommand_from available deps doctor info install list remove search sync tree help" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand pkg; and not __fish_seen_subcommand_from available deps doctor info install list remove search sync tree help" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand pkg; and not __fish_seen_subcommand_from available deps doctor info install list remove search sync tree help" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand pkg; and not __fish_seen_subcommand_from available deps doctor info install list remove search sync tree help" -f -a "available" -d 'List packages available in the R package repositories'
complete -c rig -n "__fish_rig_using_subcommand pkg; and not __fish_seen_subcommand_from available deps doctor info install list remove search sync tree help" -f -a "deps" -d 'Dependencies of a package in the repositories'
complete -c rig -n "__fish_rig_using_subcommand pkg; and not __fish_seen_subcommand_from available deps doctor info install list remove search sync tree help" -f -a "doctor" -d 'Find problems with the packages in a library'
complete -c rig -n "__fish_rig_using_subcommand pkg; and not __fish_seen_subcommand_from available deps doctor info install list remove search sync tree help" -f -a "info" -d 'Information about a package in the repositories'
complete -c rig -n "__fish_rig_using_subcommand pkg; and not __fish_seen_subcommand_from available deps doctor info install list remove search sync tree help" -f -a "install" -d 'Install packages from the repositories'
complete -c rig -n "__fish_rig_using_subcommand pkg; and not __fish_seen_subcommand_from available deps doctor info install list remove search sync tree help" -f -a "list" -d 'Packages installed in a library'
complete -c rig -n "__fish_rig_using_subcommand pkg; and not __fish_seen_subcommand_from available deps doctor info install list remove search sync tree help" -f -a "remove" -d 'Remove packages from a library'
complete -c rig -n "__fish_rig_using_subcommand pkg; and not __fish_seen_subcommand_from available deps doctor info install list remove search sync tree help" -f -a "search" -d 'Search for CRAN packages'
complete -c rig -n "__fish_rig_using_subcommand pkg; and not __fish_seen_subcommand_from available deps doctor info install list remove search sync tree help" -f -a "sync" -d 'Install the packages of a lock file into a library'
complete -c rig -n "__fish_rig_using_subcommand pkg; and not __fish_seen_subcommand_from available deps doctor info install list remove search sync tree help" -f -a "tree" -d 'Dependency tree of a package in the repositories'
complete -c rig -n "__fish_rig_using_subcommand pkg; and not __fish_seen_subcommand_from available deps doctor info install list remove search sync tree help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from available" -s r -l r-version -d 'R version whose repositories to use, instead of the default' -r
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from available" -l with-repos -l index -d 'Also use these repositories, a comma-separated list of repository names, URLs or name=URL pairs. Can be repeated.' -r
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from available" -l without-repos -l no-index -d 'Do not use these repositories, a comma-separated list, given with \'=\', e.g. --without-repos=cran. Without a value, do not use any of the configured repositories, only the ones in --with-repos. Can be repeated.' -r
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from available" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from available" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from available" -l include-archived -d 'Also list packages CRAN has archived'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from available" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from available" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from available" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from available" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from deps" -l r-version -d 'R version whose repositories to use, instead of the default' -r
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from deps" -l with-repos -l index -d 'Also use these repositories, a comma-separated list of repository names, URLs or name=URL pairs. Can be repeated.' -r
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from deps" -l without-repos -l no-index -d 'Do not use these repositories, a comma-separated list, given with \'=\', e.g. --without-repos=cran. Without a value, do not use any of the configured repositories, only the ones in --with-repos. Can be repeated.' -r
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from deps" -s v -l version -d 'package version to use (default: latest)' -r
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from deps" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from deps" -s r -l recursive -d 'Show recursive (transitive) dependencies'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from deps" -l dev -d 'Include dev (development) dependencies'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from deps" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from deps" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from deps" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from deps" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from deps" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from doctor" -s l -l library -d 'Library name or path, instead of the default library' -r
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from doctor" -s r -l r-version -d 'R version to operate on, instead of the default' -r
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from doctor" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from doctor" -l dev -d 'Also check the Suggests and Enhances dependencies'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from doctor" -l stale -d 'Warn about packages that rig did not install, if a LinkingTo dependency was built after them'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from doctor" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from doctor" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from doctor" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from doctor" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from doctor" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from info" -s r -l r-version -d 'R version whose repositories to use, instead of the default' -r
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from info" -l with-repos -l index -d 'Also use these repositories, a comma-separated list of repository names, URLs or name=URL pairs. Can be repeated.' -r
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from info" -l without-repos -l no-index -d 'Do not use these repositories, a comma-separated list, given with \'=\', e.g. --without-repos=cran. Without a value, do not use any of the configured repositories, only the ones in --with-repos. Can be repeated.' -r
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from info" -s v -l version -d 'package version to show (default: latest)' -r
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from info" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from info" -l versions -d 'List all versions of the package, instead of the details of one'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from info" -l readme -d 'Show the README of the package, instead of its metadata'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from info" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from info" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from info" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from info" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from info" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from install" -s l -l library -d 'Library name or path, instead of the default library' -r
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from install" -s r -l r-version -d 'R version to operate on, instead of the default' -r
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from install" -l platform -d 'Platform to install binary packages for, e.g. macos, windows, ubuntu-24.04, or a full platform string like aarch64-unknown-linux-gnu-ubuntu-24.04 (default: this machine). Use --platform source to install source packages only.' -r
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from install" -l prefer-binary -d 'Prefer an older version that has a binary package over a newer one that does not. Optionally give how many of the newest versions to consider, e.g. --prefer-binary=5 (default: 3).' -r
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from install" -l exclude-newer -d 'Ignore package versions published after this date. A date (2025-06-01), an RFC 3339 timestamp, or a span back from today (7 days, 2 weeks, P1M). Not before 2017-10-10.' -r
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from install" -l with-repos -l index -d 'Also use these repositories, a comma-separated list of repository names, URLs or name=URL pairs. Can be repeated.' -r
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from install" -l without-repos -l no-index -d 'Do not use these repositories, a comma-separated list, given with \'=\', e.g. --without-repos=cran. Without a value, do not use any of the configured repositories, only the ones in --with-repos. Can be repeated.' -r
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from install" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from install" -l reinstall -d 'Install the packages even if they are already up to date'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from install" -l dry-run -d 'Show what would be installed, install nothing'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from install" -l sysreqs -d 'Install the system packages the R packages need, even if the sysreqs setting turns this off'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from install" -l no-sysreqs -d 'Do not install the system packages the R packages need'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from install" -l dev -d 'Include dev (development) dependencies'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from install" -l ignore-unavailable -d 'Skip dev dependencies that are not available in the repositories, instead of failing'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from install" -l no-install-self -l no-install-project -d 'Do not install the packages named on the command line, only their dependencies. A named package is still installed if another package that is installed depends on it.'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from install" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from install" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from install" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from install" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from install" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from list" -s l -l library -d 'Library name or path, instead of the default library' -r
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from list" -s r -l r-version -d 'R version to operate on, instead of the default' -r
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from list" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from list" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from list" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from list" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from list" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from list" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from remove" -s l -l library -d 'Library name or path, instead of the default library' -r
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from remove" -s r -l r-version -d 'R version to operate on, instead of the default' -r
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from remove" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from remove" -l force -d 'Remove base packages as well, which R itself needs'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from remove" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from remove" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from remove" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from remove" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from remove" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from search" -l from -d 'Rank of the first result to show' -r
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from search" -s n -l size -d 'Number of results to show [default: 8, or 20 with --short]' -r
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from search" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from search" -s s -l short -d 'Short output, one line per package'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from search" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from search" -l user
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from search" -l admin
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from search" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from search" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from sync" -s l -l library -d 'Library name or path, instead of the default library of the R version the lock file names' -r
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from sync" -s r -l r-version -d 'R version to install with, an installed R version or one of the lock file\'s R versions (default: the default R version, if the lock file has a target for it, else the highest)' -r
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from sync" -l platform -d 'Which of the lock file\'s targets to install, when more than one matches this machine. Any spelling of the platform works, e.g. macos for aarch64-apple-darwin.' -r
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from sync" -l group -d 'Also install this dependency group, in addition to the default set (main, plus dev unless --no-dev). Repeat or comma-separate for several.' -r
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from sync" -l extra -d 'Install this optional-dependency extra. Not installed by default. Repeat or comma-separate for several.' -r
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from sync" -l max-concurrent -d 'Maximum number of concurrent installations (default: number of CPU cores, see \'concurrent-installs\' in \'rig config\')' -r
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from sync" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from sync" -l no-install-r -d 'Fail if the R version the lock file needs is not installed, instead of installing it'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from sync" -l no-install-project -l no-install-self -d 'Do not install the project\'s own package, if the lock file has one. Still installed if another package actually depends on it.'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from sync" -l no-dev -d 'Do not install the dev dependency group (default: installed alongside main). An explicit --group dev or --all-groups installs it anyway.'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from sync" -l all-groups -d 'Install every dependency group.'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from sync" -l all-extras -d 'Install every optional-dependency extra.'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from sync" -l dry-run -d 'Show what would be installed, install nothing'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from sync" -l sysreqs -d 'Install the system packages the R packages need, even if the sysreqs setting turns this off'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from sync" -l no-sysreqs -d 'Do not install the system packages the R packages need'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from sync" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from sync" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from sync" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from sync" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from tree" -s r -l r-version -d 'R version whose repositories to use, instead of the default' -r
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from tree" -l with-repos -l index -d 'Also use these repositories, a comma-separated list of repository names, URLs or name=URL pairs. Can be repeated.' -r
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from tree" -l without-repos -l no-index -d 'Do not use these repositories, a comma-separated list, given with \'=\', e.g. --without-repos=cran. Without a value, do not use any of the configured repositories, only the ones in --with-repos. Can be repeated.' -r
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from tree" -s v -l version -d 'package version to use (default: latest)' -r
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from tree" -l why -l explain -d 'Invert the tree: show what pulls this package in' -r
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from tree" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from tree" -l dev -d 'Include dev (development) dependencies'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from tree" -l no-base -d 'Leave out R and the base packages'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from tree" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from tree" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from tree" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from tree" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from tree" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from help" -f -a "available" -d 'List packages available in the R package repositories'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from help" -f -a "deps" -d 'Dependencies of a package in the repositories'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from help" -f -a "doctor" -d 'Find problems with the packages in a library'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from help" -f -a "info" -d 'Information about a package in the repositories'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from help" -f -a "install" -d 'Install packages from the repositories'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from help" -f -a "list" -d 'Packages installed in a library'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from help" -f -a "remove" -d 'Remove packages from a library'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from help" -f -a "search" -d 'Search for CRAN packages'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from help" -f -a "sync" -d 'Install the packages of a lock file into a library'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from help" -f -a "tree" -d 'Dependency tree of a package in the repositories'
complete -c rig -n "__fish_rig_using_subcommand pkg; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rig -n "__fish_rig_using_subcommand ppm; and not __fish_seen_subcommand_from builds build-log platforms r-versions status url help" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand ppm; and not __fish_seen_subcommand_from builds build-log platforms r-versions status url help" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand ppm; and not __fish_seen_subcommand_from builds build-log platforms r-versions status url help" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand ppm; and not __fish_seen_subcommand_from builds build-log platforms r-versions status url help" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand ppm; and not __fish_seen_subcommand_from builds build-log platforms r-versions status url help" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand ppm; and not __fish_seen_subcommand_from builds build-log platforms r-versions status url help" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand ppm; and not __fish_seen_subcommand_from builds build-log platforms r-versions status url help" -f -a "builds" -d 'List the published builds of a package'
complete -c rig -n "__fish_rig_using_subcommand ppm; and not __fish_seen_subcommand_from builds build-log platforms r-versions status url help" -f -a "build-log" -d 'Show the PPM build log for a package'
complete -c rig -n "__fish_rig_using_subcommand ppm; and not __fish_seen_subcommand_from builds build-log platforms r-versions status url help" -f -a "platforms" -d 'List the platforms Posit Package Manager builds for'
complete -c rig -n "__fish_rig_using_subcommand ppm; and not __fish_seen_subcommand_from builds build-log platforms r-versions status url help" -f -a "r-versions" -d 'List the R versions Posit Package Manager builds for'
complete -c rig -n "__fish_rig_using_subcommand ppm; and not __fish_seen_subcommand_from builds build-log platforms r-versions status url help" -f -a "status" -d 'Show the Posit Package Manager status report'
complete -c rig -n "__fish_rig_using_subcommand ppm; and not __fish_seen_subcommand_from builds build-log platforms r-versions status url help" -f -a "url" -d 'Print the Posit Package Manager URL'
complete -c rig -n "__fish_rig_using_subcommand ppm; and not __fish_seen_subcommand_from builds build-log platforms r-versions status url help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rig -n "__fish_rig_using_subcommand ppm; and __fish_seen_subcommand_from builds" -s v -l version -d 'package version to list (default: all)' -r
complete -c rig -n "__fish_rig_using_subcommand ppm; and __fish_seen_subcommand_from builds" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand ppm; and __fish_seen_subcommand_from builds" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand ppm; and __fish_seen_subcommand_from builds" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand ppm; and __fish_seen_subcommand_from builds" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand ppm; and __fish_seen_subcommand_from builds" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand ppm; and __fish_seen_subcommand_from builds" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand ppm; and __fish_seen_subcommand_from build-log" -s p -l platform -d 'P3M build target, e.g. macos, windows, jammy (see `rig ppm builds`); default: the current platform' -r
complete -c rig -n "__fish_rig_using_subcommand ppm; and __fish_seen_subcommand_from build-log" -s r -l r-version -d 'R version the build is for (default: the default R version)' -r
complete -c rig -n "__fish_rig_using_subcommand ppm; and __fish_seen_subcommand_from build-log" -s a -l arch -d 'CPU architecture (default: the current architecture)' -r
complete -c rig -n "__fish_rig_using_subcommand ppm; and __fish_seen_subcommand_from build-log" -s v -l version -d 'package version (default: latest)' -r
complete -c rig -n "__fish_rig_using_subcommand ppm; and __fish_seen_subcommand_from build-log" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand ppm; and __fish_seen_subcommand_from build-log" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand ppm; and __fish_seen_subcommand_from build-log" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand ppm; and __fish_seen_subcommand_from build-log" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand ppm; and __fish_seen_subcommand_from build-log" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand ppm; and __fish_seen_subcommand_from build-log" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand ppm; and __fish_seen_subcommand_from platforms" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand ppm; and __fish_seen_subcommand_from platforms" -l all -d 'Also list the platforms P3M has retired'
complete -c rig -n "__fish_rig_using_subcommand ppm; and __fish_seen_subcommand_from platforms" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand ppm; and __fish_seen_subcommand_from platforms" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand ppm; and __fish_seen_subcommand_from platforms" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand ppm; and __fish_seen_subcommand_from platforms" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand ppm; and __fish_seen_subcommand_from platforms" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand ppm; and __fish_seen_subcommand_from r-versions" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand ppm; and __fish_seen_subcommand_from r-versions" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand ppm; and __fish_seen_subcommand_from r-versions" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand ppm; and __fish_seen_subcommand_from r-versions" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand ppm; and __fish_seen_subcommand_from r-versions" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand ppm; and __fish_seen_subcommand_from r-versions" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand ppm; and __fish_seen_subcommand_from status" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand ppm; and __fish_seen_subcommand_from status" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand ppm; and __fish_seen_subcommand_from status" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand ppm; and __fish_seen_subcommand_from status" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand ppm; and __fish_seen_subcommand_from status" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand ppm; and __fish_seen_subcommand_from status" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand ppm; and __fish_seen_subcommand_from url" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand ppm; and __fish_seen_subcommand_from url" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand ppm; and __fish_seen_subcommand_from url" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand ppm; and __fish_seen_subcommand_from url" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand ppm; and __fish_seen_subcommand_from url" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand ppm; and __fish_seen_subcommand_from url" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand ppm; and __fish_seen_subcommand_from help" -f -a "builds" -d 'List the published builds of a package'
complete -c rig -n "__fish_rig_using_subcommand ppm; and __fish_seen_subcommand_from help" -f -a "build-log" -d 'Show the PPM build log for a package'
complete -c rig -n "__fish_rig_using_subcommand ppm; and __fish_seen_subcommand_from help" -f -a "platforms" -d 'List the platforms Posit Package Manager builds for'
complete -c rig -n "__fish_rig_using_subcommand ppm; and __fish_seen_subcommand_from help" -f -a "r-versions" -d 'List the R versions Posit Package Manager builds for'
complete -c rig -n "__fish_rig_using_subcommand ppm; and __fish_seen_subcommand_from help" -f -a "status" -d 'Show the Posit Package Manager status report'
complete -c rig -n "__fish_rig_using_subcommand ppm; and __fish_seen_subcommand_from help" -f -a "url" -d 'Print the Posit Package Manager URL'
complete -c rig -n "__fish_rig_using_subcommand ppm; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rig -n "__fish_rig_using_subcommand auth; and not __fish_seen_subcommand_from login logout status token help" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand auth; and not __fish_seen_subcommand_from login logout status token help" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand auth; and not __fish_seen_subcommand_from login logout status token help" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand auth; and not __fish_seen_subcommand_from login logout status token help" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand auth; and not __fish_seen_subcommand_from login logout status token help" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand auth; and not __fish_seen_subcommand_from login logout status token help" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand auth; and not __fish_seen_subcommand_from login logout status token help" -f -a "login" -d 'Save credentials for a repository or Package Manager instance'
complete -c rig -n "__fish_rig_using_subcommand auth; and not __fish_seen_subcommand_from login logout status token help" -f -a "logout" -d 'Remove saved credentials'
complete -c rig -n "__fish_rig_using_subcommand auth; and not __fish_seen_subcommand_from login logout status token help" -f -a "status" -d 'Show which repositories have credentials'
complete -c rig -n "__fish_rig_using_subcommand auth; and not __fish_seen_subcommand_from login logout status token help" -f -a "token" -d 'Print the password or token rig uses for a URL'
complete -c rig -n "__fish_rig_using_subcommand auth; and not __fish_seen_subcommand_from login logout status token help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rig -n "__fish_rig_using_subcommand auth; and __fish_seen_subcommand_from login" -s u -l username -d 'username, for the system credential store' -r
complete -c rig -n "__fish_rig_using_subcommand auth; and __fish_seen_subcommand_from login" -l password -d 'password, `-` reads it from the standard input (default: ask)' -r
complete -c rig -n "__fish_rig_using_subcommand auth; and __fish_seen_subcommand_from login" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand auth; and __fish_seen_subcommand_from login" -l no-browser -d 'do not open the browser for SSO, only print the URL'
complete -c rig -n "__fish_rig_using_subcommand auth; and __fish_seen_subcommand_from login" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand auth; and __fish_seen_subcommand_from login" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand auth; and __fish_seen_subcommand_from login" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand auth; and __fish_seen_subcommand_from login" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand auth; and __fish_seen_subcommand_from logout" -s u -l username -d 'username, for the system credential store' -r
complete -c rig -n "__fish_rig_using_subcommand auth; and __fish_seen_subcommand_from logout" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand auth; and __fish_seen_subcommand_from logout" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand auth; and __fish_seen_subcommand_from logout" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand auth; and __fish_seen_subcommand_from logout" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand auth; and __fish_seen_subcommand_from logout" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand auth; and __fish_seen_subcommand_from status" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand auth; and __fish_seen_subcommand_from status" -l connect -d 'check PPM SSO tokens with the server'
complete -c rig -n "__fish_rig_using_subcommand auth; and __fish_seen_subcommand_from status" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand auth; and __fish_seen_subcommand_from status" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand auth; and __fish_seen_subcommand_from status" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand auth; and __fish_seen_subcommand_from status" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand auth; and __fish_seen_subcommand_from status" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand auth; and __fish_seen_subcommand_from token" -s u -l username -d 'username, for the system credential store' -r
complete -c rig -n "__fish_rig_using_subcommand auth; and __fish_seen_subcommand_from token" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand auth; and __fish_seen_subcommand_from token" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand auth; and __fish_seen_subcommand_from token" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand auth; and __fish_seen_subcommand_from token" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand auth; and __fish_seen_subcommand_from token" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand auth; and __fish_seen_subcommand_from help" -f -a "login" -d 'Save credentials for a repository or Package Manager instance'
complete -c rig -n "__fish_rig_using_subcommand auth; and __fish_seen_subcommand_from help" -f -a "logout" -d 'Remove saved credentials'
complete -c rig -n "__fish_rig_using_subcommand auth; and __fish_seen_subcommand_from help" -f -a "status" -d 'Show which repositories have credentials'
complete -c rig -n "__fish_rig_using_subcommand auth; and __fish_seen_subcommand_from help" -f -a "token" -d 'Print the password or token rig uses for a URL'
complete -c rig -n "__fish_rig_using_subcommand auth; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rig -n "__fish_rig_using_subcommand repos; and not __fish_seen_subcommand_from add disable enable list available status rm setup help" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand repos; and not __fish_seen_subcommand_from add disable enable list available status rm setup help" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand repos; and not __fish_seen_subcommand_from add disable enable list available status rm setup help" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand repos; and not __fish_seen_subcommand_from add disable enable list available status rm setup help" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand repos; and not __fish_seen_subcommand_from add disable enable list available status rm setup help" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand repos; and not __fish_seen_subcommand_from add disable enable list available status rm setup help" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand repos; and not __fish_seen_subcommand_from add disable enable list available status rm setup help" -f -a "add" -d 'Add a custom R package repository'
complete -c rig -n "__fish_rig_using_subcommand repos; and not __fish_seen_subcommand_from add disable enable list available status rm setup help" -f -a "disable" -d 'Disable R package repositories for an R version'
complete -c rig -n "__fish_rig_using_subcommand repos; and not __fish_seen_subcommand_from add disable enable list available status rm setup help" -f -a "enable" -d 'Enable R package repositories for an R version'
complete -c rig -n "__fish_rig_using_subcommand repos; and not __fish_seen_subcommand_from add disable enable list available status rm setup help" -f -a "list" -d 'List configured R package repositories'
complete -c rig -n "__fish_rig_using_subcommand repos; and not __fish_seen_subcommand_from add disable enable list available status rm setup help" -f -a "available" -d 'List available R package repositories'
complete -c rig -n "__fish_rig_using_subcommand repos; and not __fish_seen_subcommand_from add disable enable list available status rm setup help" -f -a "status" -d 'Check the configured R package repositories'
complete -c rig -n "__fish_rig_using_subcommand repos; and not __fish_seen_subcommand_from add disable enable list available status rm setup help" -f -a "rm" -d 'Remove a custom R package repository'
complete -c rig -n "__fish_rig_using_subcommand repos; and not __fish_seen_subcommand_from add disable enable list available status rm setup help" -f -a "setup" -d 'Set up R package repositories'
complete -c rig -n "__fish_rig_using_subcommand repos; and not __fish_seen_subcommand_from add disable enable list available status rm setup help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from add" -l title -d 'Short title of the repository' -r
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from add" -l description -d 'Longer description of the repository' -r
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from add" -s r -l r-version -d 'With --enable, R version to enable the repository for (default: the default R version), can be repeated' -r
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from add" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from add" -l force -d 'Replace the repository if it already exists'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from add" -l enable -d 'Also enable the repository, see `rig repos enable`'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from add" -l all-versions -d 'With --enable, enable the repository for all R versions, also the ones installed later'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from add" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from add" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from add" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from add" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from disable" -s r -l r-version -d 'R version to disable the repositories for (default: the default R version), can be repeated' -r
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from disable" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from disable" -l all-versions -d 'Disable the repositories for all installed R versions'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from disable" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from disable" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from disable" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from disable" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from enable" -s r -l r-version -d 'R version to enable the repositories for (default: the default R version), can be repeated' -r
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from enable" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from enable" -l all-versions -d 'Enable the repositories for all installed R versions'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from enable" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from enable" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from enable" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from enable" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from list" -s r -l r-version -d 'R version to list repositories for, instead of the default' -r
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from list" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from list" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from list" -l all -d 'Show all repositories, not just the enabled ones'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from list" -l raw -d 'Do not resolve `%` variables in repository URLs.'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from list" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from list" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from list" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from list" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from available" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from available" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from available" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from available" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from available" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from available" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from status" -s r -l r-version -d 'R version to check repositories for, instead of the default' -r
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from status" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from status" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from status" -l all -d 'Check all repositories, not just the enabled ones'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from status" -l raw -d 'Show repository URLs without resolving `%` variables.'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from status" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from status" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from status" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from status" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from rm" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from rm" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from rm" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from rm" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from rm" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from setup" -s r -l r-version -d 'R version to set up repositories for (default: all)' -r
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from setup" -l with-repos -d 'Repositories to enable, in addition to the ones enabled by default. If --without-repos is also specified (without a value), then only these repositories will be enabled.' -r
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from setup" -l without-repos -d 'Do not set up package repositories. Alternatively, specify which ones to skip, a comma-separated list, given with \'=\', e.g. --without-repos=cran. If --with-repos is also specified, then only the repositories in that argument will be enabled.' -r
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from setup" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from setup" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from setup" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from setup" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from setup" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from help" -f -a "add" -d 'Add a custom R package repository'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from help" -f -a "disable" -d 'Disable R package repositories for an R version'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from help" -f -a "enable" -d 'Enable R package repositories for an R version'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from help" -f -a "list" -d 'List configured R package repositories'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from help" -f -a "available" -d 'List available R package repositories'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from help" -f -a "status" -d 'Check the configured R package repositories'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from help" -f -a "rm" -d 'Remove a custom R package repository'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from help" -f -a "setup" -d 'Set up R package repositories'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rig -n "__fish_rig_using_subcommand default" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand default" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand default" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand default" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand default" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand default" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand list" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand list" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand list" -l plain -d 'plain output, only the version names, one per line'
complete -c rig -n "__fish_rig_using_subcommand list" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand list" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand list" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand list" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand add" -l with-repos -d 'Repositories to enable, in addition to the ones enabled by default. If --without-repos is also specified (without a value), then only these repositories will be enabled.' -r
complete -c rig -n "__fish_rig_using_subcommand add" -l without-repos -d 'Do not set up package repositories. Alternatively, specify which ones to skip, a comma-separated list, given with \'=\', e.g. --without-repos=cran. If --with-repos is also specified, then only the repositories in that argument will be enabled.' -r
complete -c rig -n "__fish_rig_using_subcommand add" -l pak-version -d 'pak version to install.' -r -f -a "{stable\t'',devel\t''}"
complete -c rig -n "__fish_rig_using_subcommand add" -l platform -d 'Install the build for this platform, instead of auto-detecting it. Use `linux-portable` to install a portable (glibc/musl) build.' -r
complete -c rig -n "__fish_rig_using_subcommand add" -s a -l arch -d 'Select architecture: arm64 or x86_64' -r
complete -c rig -n "__fish_rig_using_subcommand add" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand add" -l without-cran-mirror -d 'Do not set the cloud CRAN mirror. Deprecated in favor of --without-repos=cran.'
complete -c rig -n "__fish_rig_using_subcommand add" -l without-p3m -d 'Do not set up P3M. Deprecated in favor of --without-repos=p3m.  [alias: --without-rspm]'
complete -c rig -n "__fish_rig_using_subcommand add" -l without-pak -d 'Do not install pak.'
complete -c rig -n "__fish_rig_using_subcommand add" -l reinstall -d 'Reinstall, even if this R version is already installed.'
complete -c rig -n "__fish_rig_using_subcommand add" -l no-default -d 'Do not make this R version the default, even if no default R version is set yet.'
complete -c rig -n "__fish_rig_using_subcommand add" -l without-path -d 'Do not put rig\'s quick-link directory on the PATH (user mode): rig otherwise edits the shell startup files on macOS and Linux, and the user PATH on Windows, when it is missing.'
complete -c rig -n "__fish_rig_using_subcommand add" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand add" -l without-sysreqs -d 'Do not set up system requirements installation.'
complete -c rig -n "__fish_rig_using_subcommand add" -l without-fonts -d 'Do not download fallback fonts. rig still writes the fontconfig configuration, but R will only see the fonts that are already installed on the system.'
complete -c rig -n "__fish_rig_using_subcommand add" -l without-translations -d 'Do not install translations.'
complete -c rig -n "__fish_rig_using_subcommand add" -l with-desktop-icon -d 'Install a desktop icon.'
complete -c rig -n "__fish_rig_using_subcommand add" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand add" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand add" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand add" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand rm" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand rm" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand rm" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand rm" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand rm" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand self; and not __fish_seen_subcommand_from update uninstall help" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand self; and not __fish_seen_subcommand_from update uninstall help" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand self; and not __fish_seen_subcommand_from update uninstall help" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand self; and not __fish_seen_subcommand_from update uninstall help" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand self; and not __fish_seen_subcommand_from update uninstall help" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand self; and not __fish_seen_subcommand_from update uninstall help" -f -a "update" -d 'Update rig to the latest release'
complete -c rig -n "__fish_rig_using_subcommand self; and not __fish_seen_subcommand_from update uninstall help" -f -a "uninstall" -d 'Remove the rig installation'
complete -c rig -n "__fish_rig_using_subcommand self; and not __fish_seen_subcommand_from update uninstall help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rig -n "__fish_rig_using_subcommand self; and __fish_seen_subcommand_from update" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand self; and __fish_seen_subcommand_from update" -l dry-run -d 'Check for a new version without downloading or installing it'
complete -c rig -n "__fish_rig_using_subcommand self; and __fish_seen_subcommand_from update" -l pre-release -d 'Include pre-releases when looking for the latest version'
complete -c rig -n "__fish_rig_using_subcommand self; and __fish_seen_subcommand_from update" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand self; and __fish_seen_subcommand_from update" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand self; and __fish_seen_subcommand_from update" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand self; and __fish_seen_subcommand_from update" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand self; and __fish_seen_subcommand_from uninstall" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand self; and __fish_seen_subcommand_from uninstall" -l dry-run -d 'Show what would be removed, without removing anything'
complete -c rig -n "__fish_rig_using_subcommand self; and __fish_seen_subcommand_from uninstall" -l force -d 'Actually remove rig, instead of just showing what would be removed'
complete -c rig -n "__fish_rig_using_subcommand self; and __fish_seen_subcommand_from uninstall" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand self; and __fish_seen_subcommand_from uninstall" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand self; and __fish_seen_subcommand_from uninstall" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand self; and __fish_seen_subcommand_from uninstall" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand self; and __fish_seen_subcommand_from help" -f -a "update" -d 'Update rig to the latest release'
complete -c rig -n "__fish_rig_using_subcommand self; and __fish_seen_subcommand_from help" -f -a "uninstall" -d 'Remove the rig installation'
complete -c rig -n "__fish_rig_using_subcommand self; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rig -n "__fish_rig_using_subcommand system; and not __fish_seen_subcommand_from clean-registry update-rtools40 rtools fix-r-alias script-assoc make-orthogonal fix-permissions no-openmp allow-debugger allow-debugger-rstudio allow-core-dumps blas forget update-certs user-mode clean-admin-r detect-platform dirs make-links fix-aliases setup-user-lib add-pak help" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand system; and not __fish_seen_subcommand_from clean-registry update-rtools40 rtools fix-r-alias script-assoc make-orthogonal fix-permissions no-openmp allow-debugger allow-debugger-rstudio allow-core-dumps blas forget update-certs user-mode clean-admin-r detect-platform dirs make-links fix-aliases setup-user-lib add-pak help" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and not __fish_seen_subcommand_from clean-registry update-rtools40 rtools fix-r-alias script-assoc make-orthogonal fix-permissions no-openmp allow-debugger allow-debugger-rstudio allow-core-dumps blas forget update-certs user-mode clean-admin-r detect-platform dirs make-links fix-aliases setup-user-lib add-pak help" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and not __fish_seen_subcommand_from clean-registry update-rtools40 rtools fix-r-alias script-assoc make-orthogonal fix-permissions no-openmp allow-debugger allow-debugger-rstudio allow-core-dumps blas forget update-certs user-mode clean-admin-r detect-platform dirs make-links fix-aliases setup-user-lib add-pak help" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and not __fish_seen_subcommand_from clean-registry update-rtools40 rtools fix-r-alias script-assoc make-orthogonal fix-permissions no-openmp allow-debugger allow-debugger-rstudio allow-core-dumps blas forget update-certs user-mode clean-admin-r detect-platform dirs make-links fix-aliases setup-user-lib add-pak help" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand system; and not __fish_seen_subcommand_from clean-registry update-rtools40 rtools fix-r-alias script-assoc make-orthogonal fix-permissions no-openmp allow-debugger allow-debugger-rstudio allow-core-dumps blas forget update-certs user-mode clean-admin-r detect-platform dirs make-links fix-aliases setup-user-lib add-pak help" -f -a "clean-registry" -d 'Clean stale R related entries in the registry'
complete -c rig -n "__fish_rig_using_subcommand system; and not __fish_seen_subcommand_from clean-registry update-rtools40 rtools fix-r-alias script-assoc make-orthogonal fix-permissions no-openmp allow-debugger allow-debugger-rstudio allow-core-dumps blas forget update-certs user-mode clean-admin-r detect-platform dirs make-links fix-aliases setup-user-lib add-pak help" -f -a "update-rtools40" -d 'Update Rtools40 MSYS2 packages'
complete -c rig -n "__fish_rig_using_subcommand system; and not __fish_seen_subcommand_from clean-registry update-rtools40 rtools fix-r-alias script-assoc make-orthogonal fix-permissions no-openmp allow-debugger allow-debugger-rstudio allow-core-dumps blas forget update-certs user-mode clean-admin-r detect-platform dirs make-links fix-aliases setup-user-lib add-pak help" -f -a "rtools" -d 'Manage Rtools installations'
complete -c rig -n "__fish_rig_using_subcommand system; and not __fish_seen_subcommand_from clean-registry update-rtools40 rtools fix-r-alias script-assoc make-orthogonal fix-permissions no-openmp allow-debugger allow-debugger-rstudio allow-core-dumps blas forget update-certs user-mode clean-admin-r detect-platform dirs make-links fix-aliases setup-user-lib add-pak help" -f -a "fix-r-alias" -d 'Make the \'R\' command start R in PowerShell'
complete -c rig -n "__fish_rig_using_subcommand system; and not __fish_seen_subcommand_from clean-registry update-rtools40 rtools fix-r-alias script-assoc make-orthogonal fix-permissions no-openmp allow-debugger allow-debugger-rstudio allow-core-dumps blas forget update-certs user-mode clean-admin-r detect-platform dirs make-links fix-aliases setup-user-lib add-pak help" -f -a "script-assoc" -d 'Run .R files with rig from the Windows command line'
complete -c rig -n "__fish_rig_using_subcommand system; and not __fish_seen_subcommand_from clean-registry update-rtools40 rtools fix-r-alias script-assoc make-orthogonal fix-permissions no-openmp allow-debugger allow-debugger-rstudio allow-core-dumps blas forget update-certs user-mode clean-admin-r detect-platform dirs make-links fix-aliases setup-user-lib add-pak help" -f -a "make-orthogonal" -d 'Make installed versions orthogonal'
complete -c rig -n "__fish_rig_using_subcommand system; and not __fish_seen_subcommand_from clean-registry update-rtools40 rtools fix-r-alias script-assoc make-orthogonal fix-permissions no-openmp allow-debugger allow-debugger-rstudio allow-core-dumps blas forget update-certs user-mode clean-admin-r detect-platform dirs make-links fix-aliases setup-user-lib add-pak help" -f -a "fix-permissions" -d 'Restrict system library permissions to admin'
complete -c rig -n "__fish_rig_using_subcommand system; and not __fish_seen_subcommand_from clean-registry update-rtools40 rtools fix-r-alias script-assoc make-orthogonal fix-permissions no-openmp allow-debugger allow-debugger-rstudio allow-core-dumps blas forget update-certs user-mode clean-admin-r detect-platform dirs make-links fix-aliases setup-user-lib add-pak help" -f -a "no-openmp" -d 'Remove OpenMP (-fopenmp) option for Apple compilers'
complete -c rig -n "__fish_rig_using_subcommand system; and not __fish_seen_subcommand_from clean-registry update-rtools40 rtools fix-r-alias script-assoc make-orthogonal fix-permissions no-openmp allow-debugger allow-debugger-rstudio allow-core-dumps blas forget update-certs user-mode clean-admin-r detect-platform dirs make-links fix-aliases setup-user-lib add-pak help" -f -a "allow-debugger" -d 'Allow debugging R with lldb and gdb'
complete -c rig -n "__fish_rig_using_subcommand system; and not __fish_seen_subcommand_from clean-registry update-rtools40 rtools fix-r-alias script-assoc make-orthogonal fix-permissions no-openmp allow-debugger allow-debugger-rstudio allow-core-dumps blas forget update-certs user-mode clean-admin-r detect-platform dirs make-links fix-aliases setup-user-lib add-pak help" -f -a "allow-debugger-rstudio" -d 'Allow debugging RStudio with lldb and gdb'
complete -c rig -n "__fish_rig_using_subcommand system; and not __fish_seen_subcommand_from clean-registry update-rtools40 rtools fix-r-alias script-assoc make-orthogonal fix-permissions no-openmp allow-debugger allow-debugger-rstudio allow-core-dumps blas forget update-certs user-mode clean-admin-r detect-platform dirs make-links fix-aliases setup-user-lib add-pak help" -f -a "allow-core-dumps" -d 'Allow creating core dumps when R crashes'
complete -c rig -n "__fish_rig_using_subcommand system; and not __fish_seen_subcommand_from clean-registry update-rtools40 rtools fix-r-alias script-assoc make-orthogonal fix-permissions no-openmp allow-debugger allow-debugger-rstudio allow-core-dumps blas forget update-certs user-mode clean-admin-r detect-platform dirs make-links fix-aliases setup-user-lib add-pak help" -f -a "blas" -d 'Manage the BLAS/LAPACK library used by R'
complete -c rig -n "__fish_rig_using_subcommand system; and not __fish_seen_subcommand_from clean-registry update-rtools40 rtools fix-r-alias script-assoc make-orthogonal fix-permissions no-openmp allow-debugger allow-debugger-rstudio allow-core-dumps blas forget update-certs user-mode clean-admin-r detect-platform dirs make-links fix-aliases setup-user-lib add-pak help" -f -a "forget" -d 'Make system forget about R installations'
complete -c rig -n "__fish_rig_using_subcommand system; and not __fish_seen_subcommand_from clean-registry update-rtools40 rtools fix-r-alias script-assoc make-orthogonal fix-permissions no-openmp allow-debugger allow-debugger-rstudio allow-core-dumps blas forget update-certs user-mode clean-admin-r detect-platform dirs make-links fix-aliases setup-user-lib add-pak help" -f -a "update-certs" -d 'Download the CA certificate bundle and configure R to use it'
complete -c rig -n "__fish_rig_using_subcommand system; and not __fish_seen_subcommand_from clean-registry update-rtools40 rtools fix-r-alias script-assoc make-orthogonal fix-permissions no-openmp allow-debugger allow-debugger-rstudio allow-core-dumps blas forget update-certs user-mode clean-admin-r detect-platform dirs make-links fix-aliases setup-user-lib add-pak help" -f -a "user-mode" -d 'Switch to user mode and clean up admin-mode installations'
complete -c rig -n "__fish_rig_using_subcommand system; and not __fish_seen_subcommand_from clean-registry update-rtools40 rtools fix-r-alias script-assoc make-orthogonal fix-permissions no-openmp allow-debugger allow-debugger-rstudio allow-core-dumps blas forget update-certs user-mode clean-admin-r detect-platform dirs make-links fix-aliases setup-user-lib add-pak help" -f -a "clean-admin-r" -d 'Remove all admin-mode R installations and links'
complete -c rig -n "__fish_rig_using_subcommand system; and not __fish_seen_subcommand_from clean-registry update-rtools40 rtools fix-r-alias script-assoc make-orthogonal fix-permissions no-openmp allow-debugger allow-debugger-rstudio allow-core-dumps blas forget update-certs user-mode clean-admin-r detect-platform dirs make-links fix-aliases setup-user-lib add-pak help" -f -a "detect-platform" -d 'Detect operating system version and distribution.'
complete -c rig -n "__fish_rig_using_subcommand system; and not __fish_seen_subcommand_from clean-registry update-rtools40 rtools fix-r-alias script-assoc make-orthogonal fix-permissions no-openmp allow-debugger allow-debugger-rstudio allow-core-dumps blas forget update-certs user-mode clean-admin-r detect-platform dirs make-links fix-aliases setup-user-lib add-pak help" -f -a "dirs" -d 'Print the directories rig uses'
complete -c rig -n "__fish_rig_using_subcommand system; and not __fish_seen_subcommand_from clean-registry update-rtools40 rtools fix-r-alias script-assoc make-orthogonal fix-permissions no-openmp allow-debugger allow-debugger-rstudio allow-core-dumps blas forget update-certs user-mode clean-admin-r detect-platform dirs make-links fix-aliases setup-user-lib add-pak help" -f -a "make-links" -d 'Create R-* quick links'
complete -c rig -n "__fish_rig_using_subcommand system; and not __fish_seen_subcommand_from clean-registry update-rtools40 rtools fix-r-alias script-assoc make-orthogonal fix-permissions no-openmp allow-debugger allow-debugger-rstudio allow-core-dumps blas forget update-certs user-mode clean-admin-r detect-platform dirs make-links fix-aliases setup-user-lib add-pak help" -f -a "fix-aliases" -d 'Fix symbolic R-* quick links'
complete -c rig -n "__fish_rig_using_subcommand system; and not __fish_seen_subcommand_from clean-registry update-rtools40 rtools fix-r-alias script-assoc make-orthogonal fix-permissions no-openmp allow-debugger allow-debugger-rstudio allow-core-dumps blas forget update-certs user-mode clean-admin-r detect-platform dirs make-links fix-aliases setup-user-lib add-pak help" -f -a "setup-user-lib" -d 'Set up automatic user package libraries [alias: create-lib]'
complete -c rig -n "__fish_rig_using_subcommand system; and not __fish_seen_subcommand_from clean-registry update-rtools40 rtools fix-r-alias script-assoc make-orthogonal fix-permissions no-openmp allow-debugger allow-debugger-rstudio allow-core-dumps blas forget update-certs user-mode clean-admin-r detect-platform dirs make-links fix-aliases setup-user-lib add-pak help" -f -a "add-pak" -d 'Install or update pak for an R version'
complete -c rig -n "__fish_rig_using_subcommand system; and not __fish_seen_subcommand_from clean-registry update-rtools40 rtools fix-r-alias script-assoc make-orthogonal fix-permissions no-openmp allow-debugger allow-debugger-rstudio allow-core-dumps blas forget update-certs user-mode clean-admin-r detect-platform dirs make-links fix-aliases setup-user-lib add-pak help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from clean-registry" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from clean-registry" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from clean-registry" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from clean-registry" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from clean-registry" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from update-rtools40" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from update-rtools40" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from update-rtools40" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from update-rtools40" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from update-rtools40" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from rtools" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from rtools" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from rtools" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from rtools" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from rtools" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from rtools" -f -a "list" -d 'List installed Rtools versions [alias: ls]'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from rtools" -f -a "add" -d 'Install new Rtools version [alias: install]'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from rtools" -f -a "rm" -d 'Remove rtools versions [aliases: del, remove, delete]'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from rtools" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from fix-r-alias" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from fix-r-alias" -l undo -d 'Remove the block rig added to the PowerShell profile(s).'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from fix-r-alias" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from fix-r-alias" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from fix-r-alias" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from fix-r-alias" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from script-assoc" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from script-assoc" -l undo -d 'Remove the association, and restore the previous one.'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from script-assoc" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from script-assoc" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from script-assoc" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from script-assoc" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from make-orthogonal" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from make-orthogonal" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from make-orthogonal" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from make-orthogonal" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from make-orthogonal" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from fix-permissions" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from fix-permissions" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from fix-permissions" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from fix-permissions" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from fix-permissions" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from no-openmp" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from no-openmp" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from no-openmp" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from no-openmp" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from no-openmp" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from allow-debugger" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from allow-debugger" -l all -d 'Update all R versions'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from allow-debugger" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from allow-debugger" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from allow-debugger" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from allow-debugger" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from allow-debugger-rstudio" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from allow-debugger-rstudio" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from allow-debugger-rstudio" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from allow-debugger-rstudio" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from allow-debugger-rstudio" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from allow-core-dumps" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from allow-core-dumps" -l all -d 'Update all R versions'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from allow-core-dumps" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from allow-core-dumps" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from allow-core-dumps" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from allow-core-dumps" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from blas" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from blas" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from blas" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from blas" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from blas" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from blas" -f -a "status" -d 'Show which BLAS/LAPACK library R is using'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from blas" -f -a "set" -d 'Switch the BLAS/LAPACK library R uses'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from blas" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from forget" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from forget" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from forget" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from forget" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from forget" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from update-certs" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from update-certs" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from update-certs" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from update-certs" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from update-certs" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from user-mode" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from user-mode" -l no-reinstall -d 'Do not reinstall admin-mode R versions in user mode.'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from user-mode" -l keep-install -d 'Keep the admin-mode R installations, do not remove them.'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from user-mode" -l keep-links -d 'Keep the admin-mode quick links, do not remove them.'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from user-mode" -l user
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from user-mode" -l admin
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from user-mode" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from user-mode" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from clean-admin-r" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from clean-admin-r" -l keep-install
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from clean-admin-r" -l keep-links
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from clean-admin-r" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from clean-admin-r" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from clean-admin-r" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from clean-admin-r" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from detect-platform" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from detect-platform" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from detect-platform" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from detect-platform" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from detect-platform" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from detect-platform" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from dirs" -s a -l arch -d 'Architecture of the R installation root (default: native arch).' -r -f -a "{x86_64\t'',aarch64\t'',arm64\t''}"
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from dirs" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from dirs" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from dirs" -l r -d 'Print the R installation root only.'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from dirs" -l rtools -d 'Print the Rtools installation root only.'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from dirs" -l binary -d 'Print the quick link directory only.'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from dirs" -l data -d 'Print rig\'s data directory only.'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from dirs" -l fonts -d 'Print the fontconfig directory only.'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from dirs" -l cache -d 'Print rig\'s cache directory only.'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from dirs" -l download -d 'Print rig\'s installer download directory only.'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from dirs" -l log -d 'Print rig\'s log directory only.'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from dirs" -l library-root -d 'Print the centralized `rig proj` library root only.'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from dirs" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from dirs" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from dirs" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from dirs" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from make-links" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from make-links" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from make-links" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from make-links" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from make-links" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from fix-aliases" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from fix-aliases" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from fix-aliases" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from fix-aliases" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from fix-aliases" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from setup-user-lib" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from setup-user-lib" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from setup-user-lib" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from setup-user-lib" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from setup-user-lib" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from add-pak" -l pak-version -d 'pak version to install.' -r -f -a "{stable\t'',devel\t''}"
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from add-pak" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from add-pak" -l devel -d 'Install the development version of pak (deprecated)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from add-pak" -l all -d 'Install pak for all R versions'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from add-pak" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from add-pak" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from add-pak" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from add-pak" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from help" -f -a "clean-registry" -d 'Clean stale R related entries in the registry'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from help" -f -a "update-rtools40" -d 'Update Rtools40 MSYS2 packages'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from help" -f -a "rtools" -d 'Manage Rtools installations'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from help" -f -a "fix-r-alias" -d 'Make the \'R\' command start R in PowerShell'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from help" -f -a "script-assoc" -d 'Run .R files with rig from the Windows command line'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from help" -f -a "make-orthogonal" -d 'Make installed versions orthogonal'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from help" -f -a "fix-permissions" -d 'Restrict system library permissions to admin'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from help" -f -a "no-openmp" -d 'Remove OpenMP (-fopenmp) option for Apple compilers'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from help" -f -a "allow-debugger" -d 'Allow debugging R with lldb and gdb'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from help" -f -a "allow-debugger-rstudio" -d 'Allow debugging RStudio with lldb and gdb'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from help" -f -a "allow-core-dumps" -d 'Allow creating core dumps when R crashes'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from help" -f -a "blas" -d 'Manage the BLAS/LAPACK library used by R'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from help" -f -a "forget" -d 'Make system forget about R installations'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from help" -f -a "update-certs" -d 'Download the CA certificate bundle and configure R to use it'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from help" -f -a "user-mode" -d 'Switch to user mode and clean up admin-mode installations'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from help" -f -a "clean-admin-r" -d 'Remove all admin-mode R installations and links'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from help" -f -a "detect-platform" -d 'Detect operating system version and distribution.'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from help" -f -a "dirs" -d 'Print the directories rig uses'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from help" -f -a "make-links" -d 'Create R-* quick links'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from help" -f -a "fix-aliases" -d 'Fix symbolic R-* quick links'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from help" -f -a "setup-user-lib" -d 'Set up automatic user package libraries [alias: create-lib]'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from help" -f -a "add-pak" -d 'Install or update pak for an R version'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rig -n "__fish_rig_using_subcommand rtools; and not __fish_seen_subcommand_from list add rm help" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand rtools; and not __fish_seen_subcommand_from list add rm help" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand rtools; and not __fish_seen_subcommand_from list add rm help" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand rtools; and not __fish_seen_subcommand_from list add rm help" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand rtools; and not __fish_seen_subcommand_from list add rm help" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand rtools; and not __fish_seen_subcommand_from list add rm help" -f -a "list" -d 'List installed Rtools versions [alias: ls]'
complete -c rig -n "__fish_rig_using_subcommand rtools; and not __fish_seen_subcommand_from list add rm help" -f -a "add" -d 'Install new Rtools version [alias: install]'
complete -c rig -n "__fish_rig_using_subcommand rtools; and not __fish_seen_subcommand_from list add rm help" -f -a "rm" -d 'Remove rtools versions [aliases: del, remove, delete]'
complete -c rig -n "__fish_rig_using_subcommand rtools; and not __fish_seen_subcommand_from list add rm help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rig -n "__fish_rig_using_subcommand rtools; and __fish_seen_subcommand_from list" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand rtools; and __fish_seen_subcommand_from list" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand rtools; and __fish_seen_subcommand_from list" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand rtools; and __fish_seen_subcommand_from list" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand rtools; and __fish_seen_subcommand_from list" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand rtools; and __fish_seen_subcommand_from list" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand rtools; and __fish_seen_subcommand_from add" -s a -l arch -d 'Architecture to install Rtools for (default: native arch).' -r -f -a "{x86_64\t'',aarch64\t'',arm64\t''}"
complete -c rig -n "__fish_rig_using_subcommand rtools; and __fish_seen_subcommand_from add" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand rtools; and __fish_seen_subcommand_from add" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand rtools; and __fish_seen_subcommand_from add" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand rtools; and __fish_seen_subcommand_from add" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand rtools; and __fish_seen_subcommand_from add" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand rtools; and __fish_seen_subcommand_from add" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand rtools; and __fish_seen_subcommand_from rm" -s a -l arch -d 'Architecture of Rtools to remove (default: native arch).' -r -f -a "{x86_64\t'',aarch64\t'',arm64\t''}"
complete -c rig -n "__fish_rig_using_subcommand rtools; and __fish_seen_subcommand_from rm" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand rtools; and __fish_seen_subcommand_from rm" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand rtools; and __fish_seen_subcommand_from rm" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand rtools; and __fish_seen_subcommand_from rm" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand rtools; and __fish_seen_subcommand_from rm" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand rtools; and __fish_seen_subcommand_from help" -f -a "list" -d 'List installed Rtools versions [alias: ls]'
complete -c rig -n "__fish_rig_using_subcommand rtools; and __fish_seen_subcommand_from help" -f -a "add" -d 'Install new Rtools version [alias: install]'
complete -c rig -n "__fish_rig_using_subcommand rtools; and __fish_seen_subcommand_from help" -f -a "rm" -d 'Remove rtools versions [aliases: del, remove, delete]'
complete -c rig -n "__fish_rig_using_subcommand rtools; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rig -n "__fish_rig_using_subcommand resolve" -l platform -d 'Use this platform, instead of auto-detecting it.' -r
complete -c rig -n "__fish_rig_using_subcommand resolve" -s a -l arch -d 'Use this architecture, instead of auto-detecting it.' -r
complete -c rig -n "__fish_rig_using_subcommand resolve" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand resolve" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand resolve" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand resolve" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand resolve" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand resolve" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand rstudio" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand rstudio" -l config-path -d 'Do not start RStudio, only print the path of the RStudio config directory'
complete -c rig -n "__fish_rig_using_subcommand rstudio" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand rstudio" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand rstudio" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand rstudio" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand library; and not __fish_seen_subcommand_from list add rm default help" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand library; and not __fish_seen_subcommand_from list add rm default help" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand library; and not __fish_seen_subcommand_from list add rm default help" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand library; and not __fish_seen_subcommand_from list add rm default help" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand library; and not __fish_seen_subcommand_from list add rm default help" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand library; and not __fish_seen_subcommand_from list add rm default help" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand library; and not __fish_seen_subcommand_from list add rm default help" -f -a "list" -d 'List libraries [alias: ls]'
complete -c rig -n "__fish_rig_using_subcommand library; and not __fish_seen_subcommand_from list add rm default help" -f -a "add" -d 'Add a new library'
complete -c rig -n "__fish_rig_using_subcommand library; and not __fish_seen_subcommand_from list add rm default help" -f -a "rm" -d 'Remove a library'
complete -c rig -n "__fish_rig_using_subcommand library; and not __fish_seen_subcommand_from list add rm default help" -f -a "default" -d 'Set the default library'
complete -c rig -n "__fish_rig_using_subcommand library; and not __fish_seen_subcommand_from list add rm default help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rig -n "__fish_rig_using_subcommand library; and __fish_seen_subcommand_from list" -s r -l r-version -d 'R version to operate on, instead of the default' -r
complete -c rig -n "__fish_rig_using_subcommand library; and __fish_seen_subcommand_from list" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand library; and __fish_seen_subcommand_from list" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand library; and __fish_seen_subcommand_from list" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand library; and __fish_seen_subcommand_from list" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand library; and __fish_seen_subcommand_from list" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand library; and __fish_seen_subcommand_from list" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand library; and __fish_seen_subcommand_from add" -s r -l r-version -d 'R version to operate on, instead of the default' -r
complete -c rig -n "__fish_rig_using_subcommand library; and __fish_seen_subcommand_from add" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand library; and __fish_seen_subcommand_from add" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand library; and __fish_seen_subcommand_from add" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand library; and __fish_seen_subcommand_from add" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand library; and __fish_seen_subcommand_from add" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand library; and __fish_seen_subcommand_from rm" -s r -l r-version -d 'R version to operate on, instead of the default' -r
complete -c rig -n "__fish_rig_using_subcommand library; and __fish_seen_subcommand_from rm" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand library; and __fish_seen_subcommand_from rm" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand library; and __fish_seen_subcommand_from rm" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand library; and __fish_seen_subcommand_from rm" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand library; and __fish_seen_subcommand_from rm" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand library; and __fish_seen_subcommand_from default" -s r -l r-version -d 'R version to operate on, instead of the default' -r
complete -c rig -n "__fish_rig_using_subcommand library; and __fish_seen_subcommand_from default" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand library; and __fish_seen_subcommand_from default" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand library; and __fish_seen_subcommand_from default" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand library; and __fish_seen_subcommand_from default" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand library; and __fish_seen_subcommand_from default" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand library; and __fish_seen_subcommand_from default" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand library; and __fish_seen_subcommand_from help" -f -a "list" -d 'List libraries [alias: ls]'
complete -c rig -n "__fish_rig_using_subcommand library; and __fish_seen_subcommand_from help" -f -a "add" -d 'Add a new library'
complete -c rig -n "__fish_rig_using_subcommand library; and __fish_seen_subcommand_from help" -f -a "rm" -d 'Remove a library'
complete -c rig -n "__fish_rig_using_subcommand library; and __fish_seen_subcommand_from help" -f -a "default" -d 'Set the default library'
complete -c rig -n "__fish_rig_using_subcommand library; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rig -n "__fish_rig_using_subcommand cache; and not __fish_seen_subcommand_from info clean help" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand cache; and not __fish_seen_subcommand_from info clean help" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand cache; and not __fish_seen_subcommand_from info clean help" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand cache; and not __fish_seen_subcommand_from info clean help" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand cache; and not __fish_seen_subcommand_from info clean help" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand cache; and not __fish_seen_subcommand_from info clean help" -f -a "info" -d 'Show cache size and contents'
complete -c rig -n "__fish_rig_using_subcommand cache; and not __fish_seen_subcommand_from info clean help" -f -a "clean" -d 'Delete cached files'
complete -c rig -n "__fish_rig_using_subcommand cache; and not __fish_seen_subcommand_from info clean help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rig -n "__fish_rig_using_subcommand cache; and __fish_seen_subcommand_from info" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand cache; and __fish_seen_subcommand_from info" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand cache; and __fish_seen_subcommand_from info" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand cache; and __fish_seen_subcommand_from info" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand cache; and __fish_seen_subcommand_from info" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand cache; and __fish_seen_subcommand_from info" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand cache; and __fish_seen_subcommand_from clean" -l category -d 'Only delete this category of cached files' -r -f -a "{built\t'',packages\t'',metadata\t'',p3m\t'',git-mirrors\t'',url-pkgs\t'',scripts\t''}"
complete -c rig -n "__fish_rig_using_subcommand cache; and __fish_seen_subcommand_from clean" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand cache; and __fish_seen_subcommand_from clean" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand cache; and __fish_seen_subcommand_from clean" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand cache; and __fish_seen_subcommand_from clean" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand cache; and __fish_seen_subcommand_from clean" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand cache; and __fish_seen_subcommand_from help" -f -a "info" -d 'Show cache size and contents'
complete -c rig -n "__fish_rig_using_subcommand cache; and __fish_seen_subcommand_from help" -f -a "clean" -d 'Delete cached files'
complete -c rig -n "__fish_rig_using_subcommand cache; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rig -n "__fish_rig_using_subcommand available" -l platform -d 'Use this platform, instead of auto-detecting it.' -r
complete -c rig -n "__fish_rig_using_subcommand available" -s a -l arch -d 'Use this architecture, instead of auto-detecting it.' -r
complete -c rig -n "__fish_rig_using_subcommand available" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand available" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand available" -l all -d 'List all available versions.'
complete -c rig -n "__fish_rig_using_subcommand available" -l list-distros -d 'List supported Linux distributions instead of R versions.'
complete -c rig -n "__fish_rig_using_subcommand available" -l list-rtools-versions -d 'List available Rtools versions instead of R versions.'
complete -c rig -n "__fish_rig_using_subcommand available" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand available" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand available" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand available" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand run" -s r -l r-version -d 'R version to use' -r
complete -c rig -n "__fish_rig_using_subcommand run" -s t -l app-type -d 'Explicitly specify app type to run' -r -f -a "{api\t'',shiny\t'',quarto-shiny\t'',rmd-shiny\t'',quarto-static\t'',rmd-static\t'',static\t''}"
complete -c rig -n "__fish_rig_using_subcommand run" -s e -l eval -d 'R expression to evaluate' -r
complete -c rig -n "__fish_rig_using_subcommand run" -s f -l script -d 'R script file to run' -r
complete -c rig -n "__fish_rig_using_subcommand run" -s P -l upgrade-package -d 'Upgrade only these packages in the environment of a script with a `# /// script` block. As <package> or <package>@<version>. Comma-separated, and can be repeated.' -r
complete -c rig -n "__fish_rig_using_subcommand run" -l cache-dir -d 'Path to the cache directory (overrides RIG_CACHE_DIR and config)' -r
complete -c rig -n "__fish_rig_using_subcommand run" -l no-project -d 'Ignore the project environment, use the default R version'
complete -c rig -n "__fish_rig_using_subcommand run" -l dry-run -d 'Show the command, but do not run it'
complete -c rig -n "__fish_rig_using_subcommand run" -l startup -d 'Print R startup message'
complete -c rig -n "__fish_rig_using_subcommand run" -l no-startup -d 'Do not print R startup message'
complete -c rig -n "__fish_rig_using_subcommand run" -l echo -d 'Print input to R'
complete -c rig -n "__fish_rig_using_subcommand run" -l no-echo -d 'Do not print input to R'
complete -c rig -n "__fish_rig_using_subcommand run" -l cmd -d 'Run `R CMD <command>` with the trailing arguments'
complete -c rig -n "__fish_rig_using_subcommand run" -l list -d 'List the scripts the project declares'
complete -c rig -n "__fish_rig_using_subcommand run" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand run" -l activate -d 'Put the selected R version on PATH for the subprocess'
complete -c rig -n "__fish_rig_using_subcommand run" -l shell -d 'Run a shell instead of R, with the selected R version on PATH'
complete -c rig -n "__fish_rig_using_subcommand run" -l rscript -d 'Run with Rscript instead of R, e.g. for scripts (no echoing of input)'
complete -c rig -n "__fish_rig_using_subcommand run" -s U -l upgrade -d 'Re-resolve every dependency of a script with a `# /// script` block, instead of keeping the versions its environment has'
complete -c rig -n "__fish_rig_using_subcommand run" -l locked -d 'Fail if the lock file of a script (<script>.lock) does not fit its `# /// script` block, instead of updating the lock file'
complete -c rig -n "__fish_rig_using_subcommand run" -l user -d 'Run in user mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand run" -l admin -d 'Run in admin mode (overrides RIG_MODE and config)'
complete -c rig -n "__fish_rig_using_subcommand run" -l no-cache -d 'Do not read or write rig\'s cache (overrides RIG_NO_CACHE and config)'
complete -c rig -n "__fish_rig_using_subcommand run" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand help; and not __fish_seen_subcommand_from config proj pkg ppm auth repos default list add rm self system rtools resolve rstudio library cache available run help" -f -a "config" -d 'Manage rig configuration'
complete -c rig -n "__fish_rig_using_subcommand help; and not __fish_seen_subcommand_from config proj pkg ppm auth repos default list add rm self system rtools resolve rstudio library cache available run help" -f -a "proj" -d 'Manage R projects (experimental)'
complete -c rig -n "__fish_rig_using_subcommand help; and not __fish_seen_subcommand_from config proj pkg ppm auth repos default list add rm self system rtools resolve rstudio library cache available run help" -f -a "pkg" -d 'Manage R packages (experimental)'
complete -c rig -n "__fish_rig_using_subcommand help; and not __fish_seen_subcommand_from config proj pkg ppm auth repos default list add rm self system rtools resolve rstudio library cache available run help" -f -a "ppm" -d 'Query Posit Package Manager (experimental)'
complete -c rig -n "__fish_rig_using_subcommand help; and not __fish_seen_subcommand_from config proj pkg ppm auth repos default list add rm self system rtools resolve rstudio library cache available run help" -f -a "auth" -d 'Manage credentials for repositories and Package Manager instances'
complete -c rig -n "__fish_rig_using_subcommand help; and not __fish_seen_subcommand_from config proj pkg ppm auth repos default list add rm self system rtools resolve rstudio library cache available run help" -f -a "repos" -d 'Manage package repositories'
complete -c rig -n "__fish_rig_using_subcommand help; and not __fish_seen_subcommand_from config proj pkg ppm auth repos default list add rm self system rtools resolve rstudio library cache available run help" -f -a "default" -d 'Print or set default R version [alias: switch]'
complete -c rig -n "__fish_rig_using_subcommand help; and not __fish_seen_subcommand_from config proj pkg ppm auth repos default list add rm self system rtools resolve rstudio library cache available run help" -f -a "list" -d 'List installed R versions [alias: ls]'
complete -c rig -n "__fish_rig_using_subcommand help; and not __fish_seen_subcommand_from config proj pkg ppm auth repos default list add rm self system rtools resolve rstudio library cache available run help" -f -a "add" -d 'Install a new R version [alias: install]'
complete -c rig -n "__fish_rig_using_subcommand help; and not __fish_seen_subcommand_from config proj pkg ppm auth repos default list add rm self system rtools resolve rstudio library cache available run help" -f -a "rm" -d 'Remove R versions [aliases: del, remove, delete]'
complete -c rig -n "__fish_rig_using_subcommand help; and not __fish_seen_subcommand_from config proj pkg ppm auth repos default list add rm self system rtools resolve rstudio library cache available run help" -f -a "self" -d 'Manage the rig installation itself'
complete -c rig -n "__fish_rig_using_subcommand help; and not __fish_seen_subcommand_from config proj pkg ppm auth repos default list add rm self system rtools resolve rstudio library cache available run help" -f -a "system" -d 'Manage current installations'
complete -c rig -n "__fish_rig_using_subcommand help; and not __fish_seen_subcommand_from config proj pkg ppm auth repos default list add rm self system rtools resolve rstudio library cache available run help" -f -a "rtools" -d 'Manage Rtools installations'
complete -c rig -n "__fish_rig_using_subcommand help; and not __fish_seen_subcommand_from config proj pkg ppm auth repos default list add rm self system rtools resolve rstudio library cache available run help" -f -a "resolve" -d 'Resolve a symbolic R version'
complete -c rig -n "__fish_rig_using_subcommand help; and not __fish_seen_subcommand_from config proj pkg ppm auth repos default list add rm self system rtools resolve rstudio library cache available run help" -f -a "rstudio" -d 'Start RStudio with specified R version'
complete -c rig -n "__fish_rig_using_subcommand help; and not __fish_seen_subcommand_from config proj pkg ppm auth repos default list add rm self system rtools resolve rstudio library cache available run help" -f -a "library" -d 'Manage package libraries [alias: lib]'
complete -c rig -n "__fish_rig_using_subcommand help; and not __fish_seen_subcommand_from config proj pkg ppm auth repos default list add rm self system rtools resolve rstudio library cache available run help" -f -a "cache" -d 'Manage rig\'s download cache'
complete -c rig -n "__fish_rig_using_subcommand help; and not __fish_seen_subcommand_from config proj pkg ppm auth repos default list add rm self system rtools resolve rstudio library cache available run help" -f -a "available" -d 'List R versions available to install.'
complete -c rig -n "__fish_rig_using_subcommand help; and not __fish_seen_subcommand_from config proj pkg ppm auth repos default list add rm self system rtools resolve rstudio library cache available run help" -f -a "run" -d 'Run R, an R script or an R project'
complete -c rig -n "__fish_rig_using_subcommand help; and not __fish_seen_subcommand_from config proj pkg ppm auth repos default list add rm self system rtools resolve rstudio library cache available run help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from config" -f -a "config-file-path" -d 'Print the path to the rig config file'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from config" -f -a "list" -d 'List the names of all config entries'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from config" -f -a "get" -d 'Get a config entry'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from config" -f -a "set" -d 'Set a config entry'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from proj" -f -a "init" -d 'Create a new R project'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from proj" -f -a "import" -d 'Create rproj.toml from a DESCRIPTION file'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from proj" -f -a "export" -d 'Create a DESCRIPTION file from rproj.toml'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from proj" -f -a "add" -d 'Add dependencies to rproj.toml'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from proj" -f -a "remove" -d 'Remove dependencies from rproj.toml'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from proj" -f -a "deps" -d 'Show project dependencies'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from proj" -f -a "tree" -d 'Dependency tree of a project'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from proj" -f -a "lock" -d 'Resolve project dependencies and write rproj.lock'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from proj" -f -a "status" -d 'Show the project\'s status'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from proj" -f -a "sync" -d 'Install the dependencies rproj.lock resolved'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from proj" -f -a "renv" -d 'Interoperate with renv, R\'s package management tool'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from pkg" -f -a "available" -d 'List packages available in the R package repositories'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from pkg" -f -a "deps" -d 'Dependencies of a package in the repositories'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from pkg" -f -a "doctor" -d 'Find problems with the packages in a library'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from pkg" -f -a "info" -d 'Information about a package in the repositories'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from pkg" -f -a "install" -d 'Install packages from the repositories'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from pkg" -f -a "list" -d 'Packages installed in a library'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from pkg" -f -a "remove" -d 'Remove packages from a library'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from pkg" -f -a "search" -d 'Search for CRAN packages'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from pkg" -f -a "sync" -d 'Install the packages of a lock file into a library'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from pkg" -f -a "tree" -d 'Dependency tree of a package in the repositories'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from ppm" -f -a "builds" -d 'List the published builds of a package'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from ppm" -f -a "build-log" -d 'Show the PPM build log for a package'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from ppm" -f -a "platforms" -d 'List the platforms Posit Package Manager builds for'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from ppm" -f -a "r-versions" -d 'List the R versions Posit Package Manager builds for'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from ppm" -f -a "status" -d 'Show the Posit Package Manager status report'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from ppm" -f -a "url" -d 'Print the Posit Package Manager URL'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from auth" -f -a "login" -d 'Save credentials for a repository or Package Manager instance'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from auth" -f -a "logout" -d 'Remove saved credentials'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from auth" -f -a "status" -d 'Show which repositories have credentials'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from auth" -f -a "token" -d 'Print the password or token rig uses for a URL'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from repos" -f -a "add" -d 'Add a custom R package repository'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from repos" -f -a "disable" -d 'Disable R package repositories for an R version'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from repos" -f -a "enable" -d 'Enable R package repositories for an R version'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from repos" -f -a "list" -d 'List configured R package repositories'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from repos" -f -a "available" -d 'List available R package repositories'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from repos" -f -a "status" -d 'Check the configured R package repositories'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from repos" -f -a "rm" -d 'Remove a custom R package repository'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from repos" -f -a "setup" -d 'Set up R package repositories'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from self" -f -a "update" -d 'Update rig to the latest release'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from self" -f -a "uninstall" -d 'Remove the rig installation'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from system" -f -a "clean-registry" -d 'Clean stale R related entries in the registry'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from system" -f -a "update-rtools40" -d 'Update Rtools40 MSYS2 packages'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from system" -f -a "rtools" -d 'Manage Rtools installations'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from system" -f -a "fix-r-alias" -d 'Make the \'R\' command start R in PowerShell'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from system" -f -a "script-assoc" -d 'Run .R files with rig from the Windows command line'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from system" -f -a "make-orthogonal" -d 'Make installed versions orthogonal'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from system" -f -a "fix-permissions" -d 'Restrict system library permissions to admin'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from system" -f -a "no-openmp" -d 'Remove OpenMP (-fopenmp) option for Apple compilers'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from system" -f -a "allow-debugger" -d 'Allow debugging R with lldb and gdb'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from system" -f -a "allow-debugger-rstudio" -d 'Allow debugging RStudio with lldb and gdb'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from system" -f -a "allow-core-dumps" -d 'Allow creating core dumps when R crashes'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from system" -f -a "blas" -d 'Manage the BLAS/LAPACK library used by R'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from system" -f -a "forget" -d 'Make system forget about R installations'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from system" -f -a "update-certs" -d 'Download the CA certificate bundle and configure R to use it'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from system" -f -a "user-mode" -d 'Switch to user mode and clean up admin-mode installations'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from system" -f -a "clean-admin-r" -d 'Remove all admin-mode R installations and links'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from system" -f -a "detect-platform" -d 'Detect operating system version and distribution.'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from system" -f -a "dirs" -d 'Print the directories rig uses'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from system" -f -a "make-links" -d 'Create R-* quick links'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from system" -f -a "fix-aliases" -d 'Fix symbolic R-* quick links'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from system" -f -a "setup-user-lib" -d 'Set up automatic user package libraries [alias: create-lib]'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from system" -f -a "add-pak" -d 'Install or update pak for an R version'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from rtools" -f -a "list" -d 'List installed Rtools versions [alias: ls]'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from rtools" -f -a "add" -d 'Install new Rtools version [alias: install]'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from rtools" -f -a "rm" -d 'Remove rtools versions [aliases: del, remove, delete]'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from library" -f -a "list" -d 'List libraries [alias: ls]'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from library" -f -a "add" -d 'Add a new library'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from library" -f -a "rm" -d 'Remove a library'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from library" -f -a "default" -d 'Set the default library'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from cache" -f -a "info" -d 'Show cache size and contents'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from cache" -f -a "clean" -d 'Delete cached files'
