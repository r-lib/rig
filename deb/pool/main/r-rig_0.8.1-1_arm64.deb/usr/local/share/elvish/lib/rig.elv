
use builtin;
use str;

set edit:completion:arg-completer[rig] = {|@words|
    fn spaces {|n|
        builtin:repeat $n ' ' | str:join ''
    }
    fn cand {|text desc|
        edit:complex-candidate $text &display=$text' '(spaces (- 14 (wcswidth $text)))$desc
    }
    var command = 'rig'
    for word $words[1..-1] {
        if (str:has-prefix $word '-') {
            break
        }
        set command = $command';'$word
    }
    var completions = [
        &'rig'= {
            cand -q 'Suppress output (overrides `--verbose`)'
            cand --quiet 'Suppress output (overrides `--verbose`)'
            cand -v 'Verbose output'
            cand --verbose 'Verbose output'
            cand --json 'Output JSON'
            cand -h 'Print help'
            cand --help 'Print help'
            cand -V 'Print version'
            cand --version 'Print version'
            cand repos 'Manage package repositories'
            cand default 'Print or set default R version [alias: switch]'
            cand list 'List installed R versions [alias: ls]'
            cand add 'Install a new R version [alias: install]'
            cand rm 'Remove R versions [aliases: del, remove, delete]'
            cand system 'Manage current installations'
            cand resolve 'Resolve a symbolic R version'
            cand rstudio 'Start RStudio with specified R version'
            cand library 'Manage package libraries [alias: lib] (experimental)'
            cand available 'List R versions available to install.'
            cand run 'Run R, an R script or an R project'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'rig;repos'= {
            cand --json 'JSON output'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
            cand list 'List configured R package repositories'
            cand available 'List available R package repositories'
            cand package-list 'List packages in R package repositories'
            cand package-info 'Information about the package in the repositories'
            cand package-versions 'List all versions of a package in the repositories'
            cand setup 'Set up R package repositories'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'rig;repos;list'= {
            cand -r 'R version to list repositories for, instead of the default'
            cand --r-version 'R version to list repositories for, instead of the default'
            cand --json 'JSON output'
            cand --all 'Show all repositories, not just the default ones'
            cand --raw 'Do not resolve `%` variables in repository URLs.'
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'rig;repos;available'= {
            cand --json 'JSON output'
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'rig;repos;package-list'= {
            cand --platform 'Platform to use, instead of the current'
            cand --r-version 'R version to use, instead of the default'
            cand --pkg-type 'Type of packages to list (e.g. source, binary)'
            cand --json 'JSON output'
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'rig;repos;package-info'= {
            cand -v 'package version to show (default: latest)'
            cand --version 'package version to show (default: latest)'
            cand --json 'JSON output'
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'rig;repos;package-versions'= {
            cand --json 'JSON output'
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'rig;repos;setup'= {
            cand -r 'R version to set up repositories for (default: all)'
            cand --r-version 'R version to set up repositories for (default: all)'
            cand --with-repos 'Repositories to enable, in addition to the ones enabled by default. If --without-repos is also specified (without a value), then only these repositories will be enabled.'
            cand --without-repos 'Do not set up package repositories. Alternatively, specify which ones to skip, a comma-separated list. If --with-repos is also specified, then only the repositories in that argument will be enabled.'
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'rig;repos;help'= {
            cand list 'List configured R package repositories'
            cand available 'List available R package repositories'
            cand package-list 'List packages in R package repositories'
            cand package-info 'Information about the package in the repositories'
            cand package-versions 'List all versions of a package in the repositories'
            cand setup 'Set up R package repositories'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'rig;repos;help;list'= {
        }
        &'rig;repos;help;available'= {
        }
        &'rig;repos;help;package-list'= {
        }
        &'rig;repos;help;package-info'= {
        }
        &'rig;repos;help;package-versions'= {
        }
        &'rig;repos;help;setup'= {
        }
        &'rig;repos;help;help'= {
        }
        &'rig;default'= {
            cand --json 'JSON output'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;list'= {
            cand --json 'JSON output'
            cand --plain 'plain output, only the version names, one per line'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;add'= {
            cand --with-repos 'Repositories to enable, in addition to the ones enabled by default. If --without-repos is also specified (without a value), then only these repositories will be enabled.'
            cand --without-repos 'Do not set up package repositories. Alternatively, specify which ones to skip, a comma-separated list. If --with-repos is also specified, then only the repositories in that argument will be enabled.'
            cand --pak-version 'pak version to install.'
            cand --without-cran-mirror 'Do not set the cloud CRAN mirror. Deprecated in favor of --without-repos=cran.'
            cand --without-p3m 'Do not set up P3M. This is the default on macOS. Deprecated in favor of --without-repos=p3m.  [alias: --without-rspm]'
            cand --without-pak 'Do not install pak.'
            cand --without-sysreqs 'Do not set up system requirements installation.'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;rm'= {
            cand --all 'remove all versions (TODO)'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;system'= {
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
            cand update-certs 'Download the CA certificate bundle and configure R to use it'
            cand detect-platform 'Detect operating system version and distribution.'
            cand make-links 'Create R-* quick links'
            cand setup-user-lib 'Set up automatic user package libraries [alias: create-lib]'
            cand add-pak 'Install or update pak for an R version'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'rig;system;update-certs'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'rig;system;detect-platform'= {
            cand --json 'JSON output'
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'rig;system;make-links'= {
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;system;setup-user-lib'= {
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;system;add-pak'= {
            cand --pak-version 'pak version to install.'
            cand --devel 'Install the development version of pak (deprecated)'
            cand --all 'Install pak for all R versions'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;system;help'= {
            cand update-certs 'Download the CA certificate bundle and configure R to use it'
            cand detect-platform 'Detect operating system version and distribution.'
            cand make-links 'Create R-* quick links'
            cand setup-user-lib 'Set up automatic user package libraries [alias: create-lib]'
            cand add-pak 'Install or update pak for an R version'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'rig;system;help;update-certs'= {
        }
        &'rig;system;help;detect-platform'= {
        }
        &'rig;system;help;make-links'= {
        }
        &'rig;system;help;setup-user-lib'= {
        }
        &'rig;system;help;add-pak'= {
        }
        &'rig;system;help;help'= {
        }
        &'rig;resolve'= {
            cand --platform 'Use this platform, instead of auto-detecting it.'
            cand -a 'Use this architecture, instead of auto-detecting it.'
            cand --arch 'Use this architecture, instead of auto-detecting it.'
            cand --json 'JSON output'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;rstudio'= {
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;library'= {
            cand --json 'JSON output'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
            cand list 'List libraries [alias: ls]'
            cand add 'Add a new library'
            cand rm 'Remove a library'
            cand default 'Set the default library'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'rig;library;list'= {
            cand --json 'JSON output'
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'rig;library;add'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'rig;library;rm'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'rig;library;default'= {
            cand --json 'JSON output'
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'rig;library;help'= {
            cand list 'List libraries [alias: ls]'
            cand add 'Add a new library'
            cand rm 'Remove a library'
            cand default 'Set the default library'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'rig;library;help;list'= {
        }
        &'rig;library;help;add'= {
        }
        &'rig;library;help;rm'= {
        }
        &'rig;library;help;default'= {
        }
        &'rig;library;help;help'= {
        }
        &'rig;available'= {
            cand --platform 'Use this platform, instead of auto-detecting it.'
            cand -a 'Use this architecture, instead of auto-detecting it.'
            cand --arch 'Use this architecture, instead of auto-detecting it.'
            cand --json 'JSON output'
            cand --all 'List all available versions.'
            cand --list-distros 'List supported Linux distributions instead of R versions.'
            cand --list-rtools-versions 'List available Rtools versions instead of R versions.'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;run'= {
            cand -r 'R version to use'
            cand --r-version 'R version to use'
            cand -t 'Explicitly specify app type to run'
            cand --app-type 'Explicitly specify app type to run'
            cand -e 'R expression to evaluate'
            cand --eval 'R expression to evaluate'
            cand -f 'R script file to run'
            cand --script 'R script file to run'
            cand --dry-run 'Show the command, but do not run it'
            cand --startup 'Print R startup message'
            cand --no-startup 'Do not print R startup message'
            cand --echo 'Print input to R'
            cand --no-echo 'Do not print input to R'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'rig;help'= {
            cand repos 'Manage package repositories'
            cand default 'Print or set default R version [alias: switch]'
            cand list 'List installed R versions [alias: ls]'
            cand add 'Install a new R version [alias: install]'
            cand rm 'Remove R versions [aliases: del, remove, delete]'
            cand system 'Manage current installations'
            cand resolve 'Resolve a symbolic R version'
            cand rstudio 'Start RStudio with specified R version'
            cand library 'Manage package libraries [alias: lib] (experimental)'
            cand available 'List R versions available to install.'
            cand run 'Run R, an R script or an R project'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'rig;help;repos'= {
            cand list 'List configured R package repositories'
            cand available 'List available R package repositories'
            cand package-list 'List packages in R package repositories'
            cand package-info 'Information about the package in the repositories'
            cand package-versions 'List all versions of a package in the repositories'
            cand setup 'Set up R package repositories'
        }
        &'rig;help;repos;list'= {
        }
        &'rig;help;repos;available'= {
        }
        &'rig;help;repos;package-list'= {
        }
        &'rig;help;repos;package-info'= {
        }
        &'rig;help;repos;package-versions'= {
        }
        &'rig;help;repos;setup'= {
        }
        &'rig;help;default'= {
        }
        &'rig;help;list'= {
        }
        &'rig;help;add'= {
        }
        &'rig;help;rm'= {
        }
        &'rig;help;system'= {
            cand update-certs 'Download the CA certificate bundle and configure R to use it'
            cand detect-platform 'Detect operating system version and distribution.'
            cand make-links 'Create R-* quick links'
            cand setup-user-lib 'Set up automatic user package libraries [alias: create-lib]'
            cand add-pak 'Install or update pak for an R version'
        }
        &'rig;help;system;update-certs'= {
        }
        &'rig;help;system;detect-platform'= {
        }
        &'rig;help;system;make-links'= {
        }
        &'rig;help;system;setup-user-lib'= {
        }
        &'rig;help;system;add-pak'= {
        }
        &'rig;help;resolve'= {
        }
        &'rig;help;rstudio'= {
        }
        &'rig;help;library'= {
            cand list 'List libraries [alias: ls]'
            cand add 'Add a new library'
            cand rm 'Remove a library'
            cand default 'Set the default library'
        }
        &'rig;help;library;list'= {
        }
        &'rig;help;library;add'= {
        }
        &'rig;help;library;rm'= {
        }
        &'rig;help;library;default'= {
        }
        &'rig;help;available'= {
        }
        &'rig;help;run'= {
        }
        &'rig;help;help'= {
        }
    ]
    $completions[$command]
}
