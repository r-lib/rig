# Print an optspec for argparse to handle cmd's options that are independent of any subcommand.
function __fish_rig_global_optspecs
	string join \n q/quiet v/verbose json h/help V/version
end

function __fish_rig_needs_command
	# Figure out if the current invocation already has a command.
	set -l cmd (commandline -opc)
	set -e cmd[1]
	argparse -s (__fish_rig_global_optspecs) -- $cmd 2>/dev/null
	or return
	if set -q argv[1]
		# Also print the command, so this can be used to figure out what it is.
		echo $argv[1]
		return 1
	end
	return 0
end

function __fish_rig_using_subcommand
	set -l cmd (__fish_rig_needs_command)
	test -z "$cmd"
	and return 1
	contains -- $cmd[1] $argv
end

complete -c rig -n "__fish_rig_needs_command" -s q -l quiet -d 'Suppress output (overrides `--verbose`)'
complete -c rig -n "__fish_rig_needs_command" -s v -l verbose -d 'Verbose output'
complete -c rig -n "__fish_rig_needs_command" -l json -d 'Output JSON'
complete -c rig -n "__fish_rig_needs_command" -s h -l help -d 'Print help'
complete -c rig -n "__fish_rig_needs_command" -s V -l version -d 'Print version'
complete -c rig -n "__fish_rig_needs_command" -f -a "repos" -d 'Manage package repositories'
complete -c rig -n "__fish_rig_needs_command" -f -a "default" -d 'Print or set default R version [alias: switch]'
complete -c rig -n "__fish_rig_needs_command" -f -a "list" -d 'List installed R versions [alias: ls]'
complete -c rig -n "__fish_rig_needs_command" -f -a "add" -d 'Install a new R version [alias: install]'
complete -c rig -n "__fish_rig_needs_command" -f -a "rm" -d 'Remove R versions [aliases: del, remove, delete]'
complete -c rig -n "__fish_rig_needs_command" -f -a "system" -d 'Manage current installations'
complete -c rig -n "__fish_rig_needs_command" -f -a "resolve" -d 'Resolve a symbolic R version'
complete -c rig -n "__fish_rig_needs_command" -f -a "rstudio" -d 'Start RStudio with specified R version'
complete -c rig -n "__fish_rig_needs_command" -f -a "library" -d 'Manage package libraries [alias: lib] (experimental)'
complete -c rig -n "__fish_rig_needs_command" -f -a "available" -d 'List R versions available to install.'
complete -c rig -n "__fish_rig_needs_command" -f -a "run" -d 'Run R, an R script or an R project'
complete -c rig -n "__fish_rig_needs_command" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rig -n "__fish_rig_using_subcommand repos; and not __fish_seen_subcommand_from list available package-list package-info package-versions setup help" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand repos; and not __fish_seen_subcommand_from list available package-list package-info package-versions setup help" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand repos; and not __fish_seen_subcommand_from list available package-list package-info package-versions setup help" -f -a "list" -d 'List configured R package repositories'
complete -c rig -n "__fish_rig_using_subcommand repos; and not __fish_seen_subcommand_from list available package-list package-info package-versions setup help" -f -a "available" -d 'List available R package repositories'
complete -c rig -n "__fish_rig_using_subcommand repos; and not __fish_seen_subcommand_from list available package-list package-info package-versions setup help" -f -a "package-list" -d 'List packages in R package repositories'
complete -c rig -n "__fish_rig_using_subcommand repos; and not __fish_seen_subcommand_from list available package-list package-info package-versions setup help" -f -a "package-info" -d 'Information about the package in the repositories'
complete -c rig -n "__fish_rig_using_subcommand repos; and not __fish_seen_subcommand_from list available package-list package-info package-versions setup help" -f -a "package-versions" -d 'List all versions of a package in the repositories'
complete -c rig -n "__fish_rig_using_subcommand repos; and not __fish_seen_subcommand_from list available package-list package-info package-versions setup help" -f -a "setup" -d 'Set up R package repositories'
complete -c rig -n "__fish_rig_using_subcommand repos; and not __fish_seen_subcommand_from list available package-list package-info package-versions setup help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from list" -s r -l r-version -d 'R version to list repositories for, instead of the default' -r
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from list" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from list" -l all -d 'Show all repositories, not just the default ones'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from list" -l raw -d 'Do not resolve `%` variables in repository URLs.'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from list" -s h -l help -d 'Print help'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from available" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from available" -s h -l help -d 'Print help'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from package-list" -l platform -d 'Platform to use, instead of the current' -r
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from package-list" -l r-version -d 'R version to use, instead of the default' -r
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from package-list" -l pkg-type -d 'Type of packages to list (e.g. source, binary)' -r
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from package-list" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from package-list" -s h -l help -d 'Print help'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from package-info" -s v -l version -d 'package version to show (default: latest)' -r
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from package-info" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from package-info" -s h -l help -d 'Print help'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from package-versions" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from package-versions" -s h -l help -d 'Print help'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from setup" -s r -l r-version -d 'R version to set up repositories for (default: all)' -r
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from setup" -l with-repos -d 'Repositories to enable, in addition to the ones enabled by default. If --without-repos is also specified (without a value), then only these repositories will be enabled.' -r
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from setup" -l without-repos -d 'Do not set up package repositories. Alternatively, specify which ones to skip, a comma-separated list. If --with-repos is also specified, then only the repositories in that argument will be enabled.' -r
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from setup" -s h -l help -d 'Print help'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from help" -f -a "list" -d 'List configured R package repositories'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from help" -f -a "available" -d 'List available R package repositories'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from help" -f -a "package-list" -d 'List packages in R package repositories'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from help" -f -a "package-info" -d 'Information about the package in the repositories'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from help" -f -a "package-versions" -d 'List all versions of a package in the repositories'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from help" -f -a "setup" -d 'Set up R package repositories'
complete -c rig -n "__fish_rig_using_subcommand repos; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rig -n "__fish_rig_using_subcommand default" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand default" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand list" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand list" -l plain -d 'plain output, only the version names, one per line'
complete -c rig -n "__fish_rig_using_subcommand list" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand add" -l with-repos -d 'Repositories to enable, in addition to the ones enabled by default. If --without-repos is also specified (without a value), then only these repositories will be enabled.' -r
complete -c rig -n "__fish_rig_using_subcommand add" -l without-repos -d 'Do not set up package repositories. Alternatively, specify which ones to skip, a comma-separated list. If --with-repos is also specified, then only the repositories in that argument will be enabled.' -r
complete -c rig -n "__fish_rig_using_subcommand add" -l pak-version -d 'pak version to install.' -r -f -a "{stable\t'',rc\t'',devel\t''}"
complete -c rig -n "__fish_rig_using_subcommand add" -l without-cran-mirror -d 'Do not set the cloud CRAN mirror. Deprecated in favor of --without-repos=cran.'
complete -c rig -n "__fish_rig_using_subcommand add" -l without-p3m -d 'Do not set up P3M. This is the default on macOS. Deprecated in favor of --without-repos=p3m.  [alias: --without-rspm]'
complete -c rig -n "__fish_rig_using_subcommand add" -l without-pak -d 'Do not install pak.'
complete -c rig -n "__fish_rig_using_subcommand add" -l without-sysreqs -d 'Do not set up system requirements installation.'
complete -c rig -n "__fish_rig_using_subcommand add" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand rm" -l all -d 'remove all versions (TODO)'
complete -c rig -n "__fish_rig_using_subcommand rm" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand system; and not __fish_seen_subcommand_from update-certs detect-platform make-links setup-user-lib add-pak help" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand system; and not __fish_seen_subcommand_from update-certs detect-platform make-links setup-user-lib add-pak help" -f -a "update-certs" -d 'Download the CA certificate bundle and configure R to use it'
complete -c rig -n "__fish_rig_using_subcommand system; and not __fish_seen_subcommand_from update-certs detect-platform make-links setup-user-lib add-pak help" -f -a "detect-platform" -d 'Detect operating system version and distribution.'
complete -c rig -n "__fish_rig_using_subcommand system; and not __fish_seen_subcommand_from update-certs detect-platform make-links setup-user-lib add-pak help" -f -a "make-links" -d 'Create R-* quick links'
complete -c rig -n "__fish_rig_using_subcommand system; and not __fish_seen_subcommand_from update-certs detect-platform make-links setup-user-lib add-pak help" -f -a "setup-user-lib" -d 'Set up automatic user package libraries [alias: create-lib]'
complete -c rig -n "__fish_rig_using_subcommand system; and not __fish_seen_subcommand_from update-certs detect-platform make-links setup-user-lib add-pak help" -f -a "add-pak" -d 'Install or update pak for an R version'
complete -c rig -n "__fish_rig_using_subcommand system; and not __fish_seen_subcommand_from update-certs detect-platform make-links setup-user-lib add-pak help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from update-certs" -s h -l help -d 'Print help'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from detect-platform" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from detect-platform" -s h -l help -d 'Print help'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from make-links" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from setup-user-lib" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from add-pak" -l pak-version -d 'pak version to install.' -r -f -a "{stable\t'',rc\t'',devel\t''}"
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from add-pak" -l devel -d 'Install the development version of pak (deprecated)'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from add-pak" -l all -d 'Install pak for all R versions'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from add-pak" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from help" -f -a "update-certs" -d 'Download the CA certificate bundle and configure R to use it'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from help" -f -a "detect-platform" -d 'Detect operating system version and distribution.'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from help" -f -a "make-links" -d 'Create R-* quick links'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from help" -f -a "setup-user-lib" -d 'Set up automatic user package libraries [alias: create-lib]'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from help" -f -a "add-pak" -d 'Install or update pak for an R version'
complete -c rig -n "__fish_rig_using_subcommand system; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rig -n "__fish_rig_using_subcommand resolve" -l platform -d 'Use this platform, instead of auto-detecting it.' -r
complete -c rig -n "__fish_rig_using_subcommand resolve" -s a -l arch -d 'Use this architecture, instead of auto-detecting it.' -r
complete -c rig -n "__fish_rig_using_subcommand resolve" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand resolve" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand rstudio" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand library; and not __fish_seen_subcommand_from list add rm default help" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand library; and not __fish_seen_subcommand_from list add rm default help" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand library; and not __fish_seen_subcommand_from list add rm default help" -f -a "list" -d 'List libraries [alias: ls]'
complete -c rig -n "__fish_rig_using_subcommand library; and not __fish_seen_subcommand_from list add rm default help" -f -a "add" -d 'Add a new library'
complete -c rig -n "__fish_rig_using_subcommand library; and not __fish_seen_subcommand_from list add rm default help" -f -a "rm" -d 'Remove a library'
complete -c rig -n "__fish_rig_using_subcommand library; and not __fish_seen_subcommand_from list add rm default help" -f -a "default" -d 'Set the default library'
complete -c rig -n "__fish_rig_using_subcommand library; and not __fish_seen_subcommand_from list add rm default help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rig -n "__fish_rig_using_subcommand library; and __fish_seen_subcommand_from list" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand library; and __fish_seen_subcommand_from list" -s h -l help -d 'Print help'
complete -c rig -n "__fish_rig_using_subcommand library; and __fish_seen_subcommand_from add" -s h -l help -d 'Print help'
complete -c rig -n "__fish_rig_using_subcommand library; and __fish_seen_subcommand_from rm" -s h -l help -d 'Print help'
complete -c rig -n "__fish_rig_using_subcommand library; and __fish_seen_subcommand_from default" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand library; and __fish_seen_subcommand_from default" -s h -l help -d 'Print help'
complete -c rig -n "__fish_rig_using_subcommand library; and __fish_seen_subcommand_from help" -f -a "list" -d 'List libraries [alias: ls]'
complete -c rig -n "__fish_rig_using_subcommand library; and __fish_seen_subcommand_from help" -f -a "add" -d 'Add a new library'
complete -c rig -n "__fish_rig_using_subcommand library; and __fish_seen_subcommand_from help" -f -a "rm" -d 'Remove a library'
complete -c rig -n "__fish_rig_using_subcommand library; and __fish_seen_subcommand_from help" -f -a "default" -d 'Set the default library'
complete -c rig -n "__fish_rig_using_subcommand library; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rig -n "__fish_rig_using_subcommand available" -l platform -d 'Use this platform, instead of auto-detecting it.' -r
complete -c rig -n "__fish_rig_using_subcommand available" -s a -l arch -d 'Use this architecture, instead of auto-detecting it.' -r
complete -c rig -n "__fish_rig_using_subcommand available" -l json -d 'JSON output'
complete -c rig -n "__fish_rig_using_subcommand available" -l all -d 'List all available versions.'
complete -c rig -n "__fish_rig_using_subcommand available" -l list-distros -d 'List supported Linux distributions instead of R versions.'
complete -c rig -n "__fish_rig_using_subcommand available" -l list-rtools-versions -d 'List available Rtools versions instead of R versions.'
complete -c rig -n "__fish_rig_using_subcommand available" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand run" -s r -l r-version -d 'R version to use' -r
complete -c rig -n "__fish_rig_using_subcommand run" -s t -l app-type -d 'Explicitly specify app type to run' -r -f -a "{api\t'',shiny\t'',quarto-shiny\t'',rmd-shiny\t'',quarto-static\t'',rmd-static\t'',static\t''}"
complete -c rig -n "__fish_rig_using_subcommand run" -s e -l eval -d 'R expression to evaluate' -r
complete -c rig -n "__fish_rig_using_subcommand run" -s f -l script -d 'R script file to run' -r
complete -c rig -n "__fish_rig_using_subcommand run" -l dry-run -d 'Show the command, but do not run it'
complete -c rig -n "__fish_rig_using_subcommand run" -l startup -d 'Print R startup message'
complete -c rig -n "__fish_rig_using_subcommand run" -l no-startup -d 'Do not print R startup message'
complete -c rig -n "__fish_rig_using_subcommand run" -l echo -d 'Print input to R'
complete -c rig -n "__fish_rig_using_subcommand run" -l no-echo -d 'Do not print input to R'
complete -c rig -n "__fish_rig_using_subcommand run" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rig -n "__fish_rig_using_subcommand help; and not __fish_seen_subcommand_from repos default list add rm system resolve rstudio library available run help" -f -a "repos" -d 'Manage package repositories'
complete -c rig -n "__fish_rig_using_subcommand help; and not __fish_seen_subcommand_from repos default list add rm system resolve rstudio library available run help" -f -a "default" -d 'Print or set default R version [alias: switch]'
complete -c rig -n "__fish_rig_using_subcommand help; and not __fish_seen_subcommand_from repos default list add rm system resolve rstudio library available run help" -f -a "list" -d 'List installed R versions [alias: ls]'
complete -c rig -n "__fish_rig_using_subcommand help; and not __fish_seen_subcommand_from repos default list add rm system resolve rstudio library available run help" -f -a "add" -d 'Install a new R version [alias: install]'
complete -c rig -n "__fish_rig_using_subcommand help; and not __fish_seen_subcommand_from repos default list add rm system resolve rstudio library available run help" -f -a "rm" -d 'Remove R versions [aliases: del, remove, delete]'
complete -c rig -n "__fish_rig_using_subcommand help; and not __fish_seen_subcommand_from repos default list add rm system resolve rstudio library available run help" -f -a "system" -d 'Manage current installations'
complete -c rig -n "__fish_rig_using_subcommand help; and not __fish_seen_subcommand_from repos default list add rm system resolve rstudio library available run help" -f -a "resolve" -d 'Resolve a symbolic R version'
complete -c rig -n "__fish_rig_using_subcommand help; and not __fish_seen_subcommand_from repos default list add rm system resolve rstudio library available run help" -f -a "rstudio" -d 'Start RStudio with specified R version'
complete -c rig -n "__fish_rig_using_subcommand help; and not __fish_seen_subcommand_from repos default list add rm system resolve rstudio library available run help" -f -a "library" -d 'Manage package libraries [alias: lib] (experimental)'
complete -c rig -n "__fish_rig_using_subcommand help; and not __fish_seen_subcommand_from repos default list add rm system resolve rstudio library available run help" -f -a "available" -d 'List R versions available to install.'
complete -c rig -n "__fish_rig_using_subcommand help; and not __fish_seen_subcommand_from repos default list add rm system resolve rstudio library available run help" -f -a "run" -d 'Run R, an R script or an R project'
complete -c rig -n "__fish_rig_using_subcommand help; and not __fish_seen_subcommand_from repos default list add rm system resolve rstudio library available run help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from repos" -f -a "list" -d 'List configured R package repositories'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from repos" -f -a "available" -d 'List available R package repositories'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from repos" -f -a "package-list" -d 'List packages in R package repositories'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from repos" -f -a "package-info" -d 'Information about the package in the repositories'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from repos" -f -a "package-versions" -d 'List all versions of a package in the repositories'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from repos" -f -a "setup" -d 'Set up R package repositories'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from system" -f -a "update-certs" -d 'Download the CA certificate bundle and configure R to use it'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from system" -f -a "detect-platform" -d 'Detect operating system version and distribution.'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from system" -f -a "make-links" -d 'Create R-* quick links'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from system" -f -a "setup-user-lib" -d 'Set up automatic user package libraries [alias: create-lib]'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from system" -f -a "add-pak" -d 'Install or update pak for an R version'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from library" -f -a "list" -d 'List libraries [alias: ls]'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from library" -f -a "add" -d 'Add a new library'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from library" -f -a "rm" -d 'Remove a library'
complete -c rig -n "__fish_rig_using_subcommand help; and __fish_seen_subcommand_from library" -f -a "default" -d 'Set the default library'
